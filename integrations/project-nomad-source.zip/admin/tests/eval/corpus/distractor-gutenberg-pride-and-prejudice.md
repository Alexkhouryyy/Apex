# Pride and Prejudice (chapters I-XIV), Jane Austen

Distractor document for the #1341 off-topic eval suite. Public domain text from Project Gutenberg (ebook #1342), boilerplate removed.

It is a truth universally acknowledged, that a single man in possession
of a good fortune must be in want of a wife.

However little known the feelings or views of such a man may be on his
first entering a neighbourhood, this truth is so well fixed in the minds
of the surrounding families, that he is considered as the rightful
property of some one or other of their daughters.

“My dear Mr. Bennet,” said his lady to him one day, “have you heard that
Netherfield Park is let at last?”

Mr. Bennet replied that he had not.

“But it is,” returned she; “for Mrs. Long has just been here, and she
told me all about it.”

Mr. Bennet made no answer.

“Do not you want to know who has taken it?” cried his wife, impatiently.

“_You_ want to tell me, and I have no objection to hearing it.”

[Illustration:

“He came down to see the place”

[_Copyright 1894 by George Allen._]]

This was invitation enough.

“Why, my dear, you must know, Mrs. Long says that Netherfield is taken
by a young man of large fortune from the north of England; that he came
down on Monday in a chaise and four to see the place, and was so much
delighted with it that he agreed with Mr. Morris immediately; that he is
to take possession before Michaelmas, and some of his servants are to be
in the house by the end of next week.”

“What is his name?”

“Bingley.”

“Is he married or single?”

“Oh, single, my dear, to be sure! A single man of large fortune; four or
five thousand a year. What a fine thing for our girls!”

“How so? how can it affect them?”

“My dear Mr. Bennet,” replied his wife, “how can you be so tiresome? You
must know that I am thinking of his marrying one of them.”

“Is that his design in settling here?”

“Design? Nonsense, how can you talk so! But it is very likely that he
_may_ fall in love with one of them, and therefore you must visit him as
soon as he comes.”

“I see no occasion for that. You and the girls may go--or you may send
them by themselves, which perhaps will be still better; for as you are
as handsome as any of them, Mr. Bingley might like you the best of the
party.”

“My dear, you flatter me. I certainly _have_ had my share of beauty, but
I do not pretend to be anything extraordinary now. When a woman has five
grown-up daughters, she ought to give over thinking of her own beauty.”

“In such cases, a woman has not often much beauty to think of.”

“But, my dear, you must indeed go and see Mr. Bingley when he comes into
the neighbourhood.”

“It is more than I engage for, I assure you.”

“But consider your daughters. Only think what an establishment it would
be for one of them. Sir William and Lady Lucas are determined to go,
merely on that account; for in general, you know, they visit no new
comers. Indeed you must go, for it will be impossible for _us_ to visit
him, if you do not.”

“You are over scrupulous, surely. I dare say Mr. Bingley will be very
glad to see you; and I will send a few lines by you to assure him of my
hearty consent to his marrying whichever he chooses of the girls--though
I must throw in a good word for my little Lizzy.”

“I desire you will do no such thing. Lizzy is not a bit better than the
others: and I am sure she is not half so handsome as Jane, nor half so
good-humoured as Lydia. But you are always giving _her_ the preference.”

“They have none of them much to recommend them,” replied he: “they are
all silly and ignorant like other girls; but Lizzy has something more of
quickness than her sisters.”

“Mr. Bennet, how can you abuse your own children in such a way? You take
delight in vexing me. You have no compassion on my poor nerves.”

“You mistake me, my dear. I have a high respect for your nerves. They
are my old friends. I have heard you mention them with consideration
these twenty years at least.”

“Ah, you do not know what I suffer.”

“But I hope you will get over it, and live to see many young men of four
thousand a year come into the neighbourhood.”

“It will be no use to us, if twenty such should come, since you will not
visit them.”

“Depend upon it, my dear, that when there are twenty, I will visit them
all.”

Mr. Bennet was so odd a mixture of quick parts, sarcastic humour,
reserve, and caprice, that the experience of three-and-twenty years had
been insufficient to make his wife understand his character. _Her_ mind
was less difficult to develope. She was a woman of mean understanding,
little information, and uncertain temper. When she was discontented, she
fancied herself nervous. The business of her life was to get her
daughters married: its solace was visiting and news.

[Illustration: M^{r.} & M^{rs.} Bennet

[_Copyright 1894 by George Allen._]]

[Illustration:

“I hope Mr. Bingley will like it”

[_Copyright 1894 by George Allen._]]

CHAPTER II.

[Illustration]

Mr. Bennet was among the earliest of those who waited on Mr. Bingley. He
had always intended to visit him, though to the last always assuring his
wife that he should not go; and till the evening after the visit was
paid she had no knowledge of it. It was then disclosed in the following
manner. Observing his second daughter employed in trimming a hat, he
suddenly addressed her with,--

“I hope Mr. Bingley will like it, Lizzy.”

“We are not in a way to know _what_ Mr. Bingley likes,” said her mother,
resentfully, “since we are not to visit.”

“But you forget, mamma,” said Elizabeth, “that we shall meet him at the
assemblies, and that Mrs. Long has promised to introduce him.”

“I do not believe Mrs. Long will do any such thing. She has two nieces
of her own. She is a selfish, hypocritical woman, and I have no opinion
of her.”

“No more have I,” said Mr. Bennet; “and I am glad to find that you do
not depend on her serving you.”

Mrs. Bennet deigned not to make any reply; but, unable to contain
herself, began scolding one of her daughters.

“Don’t keep coughing so, Kitty, for heaven’s sake! Have a little
compassion on my nerves. You tear them to pieces.”

“Kitty has no discretion in her coughs,” said her father; “she times
them ill.”

“I do not cough for my own amusement,” replied Kitty, fretfully. “When
is your next ball to be, Lizzy?”

“To-morrow fortnight.”

“Ay, so it is,” cried her mother, “and Mrs. Long does not come back till
the day before; so, it will be impossible for her to introduce him, for
she will not know him herself.”

“Then, my dear, you may have the advantage of your friend, and introduce
Mr. Bingley to _her_.”

“Impossible, Mr. Bennet, impossible, when I am not acquainted with him
myself; how can you be so teasing?”

“I honour your circumspection. A fortnight’s acquaintance is certainly
very little. One cannot know what a man really is by the end of a
fortnight. But if _we_ do not venture, somebody else will; and after
all, Mrs. Long and her nieces must stand their chance; and, therefore,
as she will think it an act of kindness, if you decline the office, I
will take it on myself.”

The girls stared at their father. Mrs. Bennet said only, “Nonsense,
nonsense!”

“What can be the meaning of that emphatic exclamation?” cried he. “Do
you consider the forms of introduction, and the stress that is laid on
them, as nonsense? I cannot quite agree with you _there_. What say you,
Mary? For you are a young lady of deep reflection, I know, and read
great books, and make extracts.”

Mary wished to say something very sensible, but knew not how.

“While Mary is adjusting her ideas,” he continued, “let us return to Mr.
Bingley.”

“I am sick of Mr. Bingley,” cried his wife.

“I am sorry to hear _that_; but why did you not tell me so before? If I
had known as much this morning, I certainly would not have called on
him. It is very unlucky; but as I have actually paid the visit, we
cannot escape the acquaintance now.”

The astonishment of the ladies was just what he wished--that of Mrs.
Bennet perhaps surpassing the rest; though when the first tumult of joy
was over, she began to declare that it was what she had expected all the
while.

“How good it was in you, my dear Mr. Bennet! But I knew I should
persuade you at last. I was sure you loved your girls too well to
neglect such an acquaintance. Well, how pleased I am! And it is such a
good joke, too, that you should have gone this morning, and never said a
word about it till now.”

“Now, Kitty, you may cough as much as you choose,” said Mr. Bennet; and,
as he spoke, he left the room, fatigued with the raptures of his wife.

“What an excellent father you have, girls,” said she, when the door was
shut. “I do not know how you will ever make him amends for his kindness;
or me either, for that matter. At our time of life, it is not so
pleasant, I can tell you, to be making new acquaintances every day; but
for your sakes we would do anything. Lydia, my love, though you _are_
the youngest, I dare say Mr. Bingley will dance with you at the next
ball.”

“Oh,” said Lydia, stoutly, “I am not afraid; for though I _am_ the
youngest, I’m the tallest.”

The rest of the evening was spent in conjecturing how soon he would
return Mr. Bennet’s visit, and determining when they should ask him to
dinner.

[Illustration: “I’m the tallest”]

[Illustration:

     “He rode a black horse”
]

CHAPTER III.

[Illustration]

Not all that Mrs. Bennet, however, with the assistance of her five
daughters, could ask on the subject, was sufficient to draw from her
husband any satisfactory description of Mr. Bingley. They attacked him
in various ways, with barefaced questions, ingenious suppositions, and
distant surmises; but he eluded the skill of them all; and they were at
last obliged to accept the second-hand intelligence of their neighbour,
Lady Lucas. Her report was highly favourable. Sir William had been
delighted with him. He was quite young, wonderfully handsome, extremely
agreeable, and, to crown the whole, he meant to be at the next assembly
with a large party. Nothing could be more delightful! To be fond of
dancing was a certain step towards falling in love; and very lively
hopes of Mr. Bingley’s heart were entertained.

“If I can but see one of my daughters happily settled at Netherfield,”
said Mrs. Bennet to her husband, “and all the others equally well
married, I shall have nothing to wish for.”

In a few days Mr. Bingley returned Mr. Bennet’s visit, and sat about ten
minutes with him in his library. He had entertained hopes of being
admitted to a sight of the young ladies, of whose beauty he had heard
much; but he saw only the father. The ladies were somewhat more
fortunate, for they had the advantage of ascertaining, from an upper
window, that he wore a blue coat and rode a black horse.

An invitation to dinner was soon afterwards despatched; and already had
Mrs. Bennet planned the courses that were to do credit to her
housekeeping, when an answer arrived which deferred it all. Mr. Bingley
was obliged to be in town the following day, and consequently unable to
accept the honour of their invitation, etc. Mrs. Bennet was quite
disconcerted. She could not imagine what business he could have in town
so soon after his arrival in Hertfordshire; and she began to fear that
he might always be flying about from one place to another, and never
settled at Netherfield as he ought to be. Lady Lucas quieted her fears a
little by starting the idea of his

[Illustration:

     “When the Party entered”

[_Copyright 1894 by George Allen._]]

being gone to London only to get a large party for the ball; and a
report soon followed that Mr. Bingley was to bring twelve ladies and
seven gentlemen with him to the assembly. The girls grieved over such a
number of ladies; but were comforted the day before the ball by hearing
that, instead of twelve, he had brought only six with him from London,
his five sisters and a cousin. And when the party entered the
assembly-room, it consisted of only five altogether: Mr. Bingley, his
two sisters, the husband of the eldest, and another young man.

Mr. Bingley was good-looking and gentlemanlike: he had a pleasant
countenance, and easy, unaffected manners. His sisters were fine women,
with an air of decided fashion. His brother-in-law, Mr. Hurst, merely
looked the gentleman; but his friend Mr. Darcy soon drew the attention
of the room by his fine, tall person, handsome features, noble mien, and
the report, which was in general circulation within five minutes after
his entrance, of his having ten thousand a year. The gentlemen
pronounced him to be a fine figure of a man, the ladies declared he was
much handsomer than Mr. Bingley, and he was looked at with great
admiration for about half the evening, till his manners gave a disgust
which turned the tide of his popularity; for he was discovered to be
proud, to be above his company, and above being pleased; and not all his
large estate in Derbyshire could save him from having a most forbidding,
disagreeable countenance, and being unworthy to be compared with his
friend.

Mr. Bingley had soon made himself acquainted with all the principal
people in the room: he was lively and unreserved, danced every dance,
was angry that the ball closed so early, and talked of giving one
himself at Netherfield. Such amiable qualities must speak for
themselves. What a contrast between him and his friend! Mr. Darcy danced
only once with Mrs. Hurst and once with Miss Bingley, declined being
introduced to any other lady, and spent the rest of the evening in
walking about the room, speaking occasionally to one of his own party.
His character was decided. He was the proudest, most disagreeable man in
the world, and everybody hoped that he would never come there again.
Amongst the most violent against him was Mrs. Bennet, whose dislike of
his general behaviour was sharpened into particular resentment by his
having slighted one of her daughters.

Elizabeth Bennet had been obliged, by the scarcity of gentlemen, to sit
down for two dances; and during part of that time, Mr. Darcy had been
standing near enough for her to overhear a conversation between him and
Mr. Bingley, who came from the dance for a few minutes to press his
friend to join it.

“Come, Darcy,” said he, “I must have you dance. I hate to see you
standing about by yourself in this stupid manner. You had much better
dance.”

“I certainly shall not. You know how I detest it, unless I am
particularly acquainted with my partner. At such an assembly as this, it
would be insupportable. Your sisters are engaged, and there is not
another woman in the room whom it would not be a punishment to me to
stand up with.”

“I would not be so fastidious as you are,” cried Bingley, “for a
kingdom! Upon my honour, I never met with so many pleasant girls in my
life as I have this evening; and there are several of them, you see,
uncommonly pretty.”

“_You_ are dancing with the only handsome girl in the room,” said Mr.
Darcy, looking at the eldest Miss Bennet.

“Oh, she is the most beautiful creature I ever beheld! But there is one
of her sisters sitting down just behind you, who is very pretty, and I
dare say very agreeable. Do let me ask my partner to introduce you.”

[Illustration:

“She is tolerable”

[_Copyright 1894 by George Allen._]]

“Which do you mean?” and turning round, he looked for a moment at
Elizabeth, till, catching her eye, he withdrew his own, and coldly said,
“She is tolerable: but not handsome enough to tempt _me_; and I am in no
humour at present to give consequence to young ladies who are slighted
by other men. You had better return to your partner and enjoy her
smiles, for you are wasting your time with me.”

Mr. Bingley followed his advice. Mr. Darcy walked off; and Elizabeth
remained with no very cordial feelings towards him. She told the story,
however, with great spirit among her friends; for she had a lively,
playful disposition, which delighted in anything ridiculous.

The evening altogether passed off pleasantly to the whole family. Mrs.
Bennet had seen her eldest daughter much admired by the Netherfield
party. Mr. Bingley had danced with her twice, and she had been
distinguished by his sisters. Jane was as much gratified by this as her
mother could be, though in a quieter way. Elizabeth felt Jane’s
pleasure. Mary had heard herself mentioned to Miss Bingley as the most
accomplished girl in the neighbourhood; and Catherine and Lydia had been
fortunate enough to be never without partners, which was all that they
had yet learnt to care for at a ball. They returned, therefore, in good
spirits to Longbourn, the village where they lived, and of which they
were the principal inhabitants. They found Mr. Bennet still up. With a
book, he was regardless of time; and on the present occasion he had a
good deal of curiosity as to the event of an evening which had raised
such splendid expectations. He had rather hoped that all his wife’s
views on the stranger would be disappointed; but he soon found that he
had a very different story to hear.

“Oh, my dear Mr. Bennet,” as she entered the room, “we have had a most
delightful evening, a most excellent ball. I wish you had been there.
Jane was so admired, nothing could be like it. Everybody said how well
she looked; and Mr. Bingley thought her quite beautiful, and danced with
her twice. Only think of _that_, my dear: he actually danced with her
twice; and she was the only creature in the room that he asked a second
time. First of all, he asked Miss Lucas. I was so vexed to see him stand
up with her; but, however, he did not admire her at all; indeed, nobody
can, you know; and he seemed quite struck with Jane as she was going
down the dance. So he inquired who she was, and got introduced, and
asked her for the two next. Then, the two third he danced with Miss
King, and the two fourth with Maria Lucas, and the two fifth with Jane
again, and the two sixth with Lizzy, and the _Boulanger_----”

“If he had had any compassion for _me_,” cried her husband impatiently,
“he would not have danced half so much! For God’s sake, say no more of
his partners. O that he had sprained his ancle in the first dance!”

“Oh, my dear,” continued Mrs. Bennet, “I am quite delighted with him. He
is so excessively handsome! and his sisters are charming women. I never
in my life saw anything more elegant than their dresses. I dare say the
lace upon Mrs. Hurst’s gown----”

Here she was interrupted again. Mr. Bennet protested against any
description of finery. She was therefore obliged to seek another branch
of the subject, and related, with much bitterness of spirit, and some
exaggeration, the shocking rudeness of Mr. Darcy.

“But I can assure you,” she added, “that Lizzy does not lose much by not
suiting _his_ fancy; for he is a most disagreeable, horrid man, not at
all worth pleasing. So high and so conceited, that there was no enduring
him! He walked here, and he walked there, fancying himself so very
great! Not handsome enough to dance with! I wish you had been there, my
dear, to have given him one of your set-downs. I quite detest the man.”

[Illustration]

CHAPTER IV.

[Illustration]

When Jane and Elizabeth were alone, the former, who had been cautious in
her praise of Mr. Bingley before, expressed to her sister how very much
she admired him.

“He is just what a young man ought to be,” said she, “sensible,
good-humoured, lively; and I never saw such happy manners! so much ease,
with such perfect good breeding!”

“He is also handsome,” replied Elizabeth, “which a young man ought
likewise to be if he possibly can. His character is thereby complete.”

“I was very much flattered by his asking me to dance a second time. I
did not expect such a compliment.”

“Did not you? _I_ did for you. But that is one great difference between
us. Compliments always take _you_ by surprise, and _me_ never. What
could be more natural than his asking you again? He could not help
seeing that you were about five times as pretty as every other woman in
the room. No thanks to his gallantry for that. Well, he certainly is
very agreeable, and I give you leave to like him. You have liked many a
stupider person.”

“Dear Lizzy!”

“Oh, you are a great deal too apt, you know, to like people in general.
You never see a fault in anybody. All the world are good and agreeable
in your eyes. I never heard you speak ill of a human being in my life.”

“I would wish not to be hasty in censuring anyone; but I always speak
what I think.”

“I know you do: and it is _that_ which makes the wonder. With _your_
good sense, to be so honestly blind to the follies and nonsense of
others! Affectation of candour is common enough; one meets with it
everywhere. But to be candid without ostentation or design,--to take the
good of everybody’s character and make it still better, and say nothing
of the bad,--belongs to you alone. And so, you like this man’s sisters,
too, do you? Their manners are not equal to his.”

“Certainly not, at first; but they are very pleasing women when you
converse with them. Miss Bingley is to live with her brother, and keep
his house; and I am much mistaken if we shall not find a very charming
neighbour in her.”

Elizabeth listened in silence, but was not convinced: their behaviour at
the assembly had not been calculated to please in general; and with more
quickness of observation and less pliancy of temper than her sister, and
with a judgment, too, unassailed by any attention to herself, she was
very little disposed to approve them. They were, in fact, very fine
ladies; not deficient in good-humour when they were pleased, nor in the
power of being agreeable where they chose it; but proud and conceited.
They were rather handsome; had been educated in one of the first private
seminaries in town; had a fortune of twenty thousand pounds; were in the
habit of spending more than they ought, and of associating with people
of rank; and were, therefore, in every respect entitled to think well of
themselves and meanly of others. They were of a respectable family in
the north of England; a circumstance more deeply impressed on their
memories than that their brother’s fortune and their own had been
acquired by trade.

Mr. Bingley inherited property to the amount of nearly a hundred
thousand pounds from his father, who had intended to purchase an estate,
but did not live to do it. Mr. Bingley intended it likewise, and
sometimes made choice of his county; but, as he was now provided with a
good house and the liberty of a manor, it was doubtful to many of those
who best knew the easiness of his temper, whether he might not spend the
remainder of his days at Netherfield, and leave the next generation to
purchase.

His sisters were very anxious for his having an estate of his own; but
though he was now established only as a tenant, Miss Bingley was by no
means unwilling to preside at his table; nor was Mrs. Hurst, who had
married a man of more fashion than fortune, less disposed to consider
his house as her home when it suited her. Mr. Bingley had not been of
age two years when he was tempted, by an accidental recommendation, to
look at Netherfield House. He did look at it, and into it, for half an
hour; was pleased with the situation and the principal rooms, satisfied
with what the owner said in its praise, and took it immediately.

Between him and Darcy there was a very steady friendship, in spite of a
great opposition of character. Bingley was endeared to Darcy by the
easiness, openness, and ductility of his temper, though no disposition
could offer a greater contrast to his own, and though with his own he
never appeared dissatisfied. On the strength of Darcy’s regard, Bingley
had the firmest reliance, and of his judgment the highest opinion. In
understanding, Darcy was the superior. Bingley was by no means
deficient; but Darcy was clever. He was at the same time haughty,
reserved, and fastidious; and his manners, though well bred, were not
inviting. In that respect his friend had greatly the advantage. Bingley
was sure of being liked wherever he appeared; Darcy was continually
giving offence.

The manner in which they spoke of the Meryton assembly was sufficiently
characteristic. Bingley had never met with pleasanter people or prettier
girls in his life; everybody had been most kind and attentive to him;
there had been no formality, no stiffness; he had soon felt acquainted
with all the room; and as to Miss Bennet, he could not conceive an angel
more beautiful. Darcy, on the contrary, had seen a collection of people
in whom there was little beauty and no fashion, for none of whom he had
felt the smallest interest, and from none received either attention or
pleasure. Miss Bennet he acknowledged to be pretty; but she smiled too
much.

Mrs. Hurst and her sister allowed it to be so; but still they admired
her and liked her, and pronounced her to be a sweet girl, and one whom
they should not object to know more of. Miss Bennet was therefore
established as a sweet girl; and their brother felt authorized by such
commendation to think of her as he chose.

[Illustration: [_Copyright 1894 by George Allen._]]

CHAPTER V.

[Illustration]

Within a short walk of Longbourn lived a family with whom the Bennets
were particularly intimate. Sir William Lucas had been formerly in trade
in Meryton, where he had made a tolerable fortune, and risen to the
honour of knighthood by an address to the king during his mayoralty. The
distinction had, perhaps, been felt too strongly. It had given him a
disgust to his business and to his residence in a small market town;
and, quitting them both, he had removed with his family to a house about
a mile from Meryton, denominated from that period Lucas Lodge; where he
could think with pleasure of his own importance, and, unshackled by
business, occupy himself solely in being civil to all the world. For,
though elated by his rank, it did not render him supercilious; on the
contrary, he was all attention to everybody. By nature inoffensive,
friendly, and obliging, his presentation at St. James’s had made him
courteous.

Lady Lucas was a very good kind of woman, not too clever to be a
valuable neighbour to Mrs. Bennet. They had several children. The eldest
of them, a sensible, intelligent young woman, about twenty-seven, was
Elizabeth’s intimate friend.

That the Miss Lucases and the Miss Bennets should meet to talk over a
ball was absolutely necessary; and the morning after the assembly
brought the former to Longbourn to hear and to communicate.

“_You_ began the evening well, Charlotte,” said Mrs. Bennet, with civil
self-command, to Miss Lucas. “_You_ were Mr. Bingley’s first choice.”

“Yes; but he seemed to like his second better.”

“Oh, you mean Jane, I suppose, because he danced with her twice. To be
sure that _did_ seem as if he admired her--indeed, I rather believe he
_did_--I heard something about it--but I hardly know what--something
about Mr. Robinson.”

“Perhaps you mean what I overheard between him and Mr. Robinson: did not
I mention it to you? Mr. Robinson’s asking him how he liked our Meryton
assemblies, and whether he did not think there were a great many pretty
women in the room, and _which_ he thought the prettiest? and his
answering immediately to the last question, ‘Oh, the eldest Miss Bennet,
beyond a doubt: there cannot be two opinions on that point.’”

“Upon my word! Well, that was very decided, indeed--that does seem as
if--but, however, it may all come to nothing, you know.”

“_My_ overhearings were more to the purpose than _yours_, Eliza,” said
Charlotte. “Mr. Darcy is not so well worth listening to as his friend,
is he? Poor Eliza! to be only just _tolerable_.”

“I beg you will not put it into Lizzy’s head to be vexed by his
ill-treatment, for he is such a disagreeable man that it would be quite
a misfortune to be liked by him. Mrs. Long told me last night that he
sat close to her for half an hour without once opening his lips.”

[Illustration: “Without once opening his lips”

[_Copyright 1894 by George Allen._]]

“Are you quite sure, ma’am? Is not there a little mistake?” said Jane.
“I certainly saw Mr. Darcy speaking to her.”

“Ay, because she asked him at last how he liked Netherfield, and he
could not help answering her; but she said he seemed very angry at being
spoke to.”

“Miss Bingley told me,” said Jane, “that he never speaks much unless
among his intimate acquaintance. With _them_ he is remarkably
agreeable.”

“I do not believe a word of it, my dear. If he had been so very
agreeable, he would have talked to Mrs. Long. But I can guess how it
was; everybody says that he is eat up with pride, and I dare say he had
heard somehow that Mrs. Long does not keep a carriage, and had to come
to the ball in a hack chaise.”

“I do not mind his not talking to Mrs. Long,” said Miss Lucas, “but I
wish he had danced with Eliza.”

“Another time, Lizzy,” said her mother, “I would not dance with _him_,
if I were you.”

“I believe, ma’am, I may safely promise you _never_ to dance with him.”

“His pride,” said Miss Lucas, “does not offend _me_ so much as pride
often does, because there is an excuse for it. One cannot wonder that so
very fine a young man, with family, fortune, everything in his favour,
should think highly of himself. If I may so express it, he has a _right_
to be proud.”

“That is very true,” replied Elizabeth, “and I could easily forgive
_his_ pride, if he had not mortified _mine_.”

“Pride,” observed Mary, who piqued herself upon the solidity of her
reflections, “is a very common failing, I believe. By all that I have
ever read, I am convinced that it is very common indeed; that human
nature is particularly prone to it, and that there are very few of us
who do not cherish a feeling of self-complacency on the score of some
quality or other, real or imaginary. Vanity and pride are different
things, though the words are often used synonymously. A person may be
proud without being vain. Pride relates more to our opinion of
ourselves; vanity to what we would have others think of us.”

“If I were as rich as Mr. Darcy,” cried a young Lucas, who came with his
sisters, “I should not care how proud I was. I would keep a pack of
foxhounds, and drink a bottle of wine every day.”

“Then you would drink a great deal more than you ought,” said Mrs.
Bennet; “and if I were to see you at it, I should take away your bottle
directly.”

The boy protested that she should not; she continued to declare that she
would; and the argument ended only with the visit.

[Illustration]

[Illustration]

CHAPTER VI.

[Illustration]

The ladies of Longbourn soon waited on those of Netherfield. The visit
was returned in due form. Miss Bennet’s pleasing manners grew on the
good-will of Mrs. Hurst and Miss Bingley; and though the mother was
found to be intolerable, and the younger sisters not worth speaking to,
a wish of being better acquainted with _them_ was expressed towards the
two eldest. By Jane this attention was received with the greatest
pleasure; but Elizabeth still saw superciliousness in their treatment of
everybody, hardly excepting even her sister, and could not like them;
though their kindness to Jane, such as it was, had a value, as arising,
in all probability, from the influence of their brother’s admiration. It
was generally evident, whenever they met, that he _did_ admire her; and
to _her_ it was equally evident that Jane was yielding to the preference
which she had begun to entertain for him from the first, and was in a
way to be very much in love; but she considered with pleasure that it
was not likely to be discovered by the world in general, since Jane
united with great strength of feeling, a composure of temper and an
uniform cheerfulness of manner, which would guard her from the
suspicions of the impertinent. She mentioned this to her friend, Miss
Lucas.

“It may, perhaps, be pleasant,” replied Charlotte, “to be able to impose
on the public in such a case; but it is sometimes a disadvantage to be
so very guarded. If a woman conceals her affection with the same skill
from the object of it, she may lose the opportunity of fixing him; and
it will then be but poor consolation to believe the world equally in the
dark. There is so much of gratitude or vanity in almost every
attachment, that it is not safe to leave any to itself. We can all
_begin_ freely--a slight preference is natural enough; but there are
very few of us who have heart enough to be really in love without
encouragement. In nine cases out of ten, a woman had better show _more_
affection than she feels. Bingley likes your sister undoubtedly; but he
may never do more than like her, if she does not help him on.”

“But she does help him on, as much as her nature will allow. If _I_ can
perceive her regard for him, he must be a simpleton indeed not to
discover it too.”

“Remember, Eliza, that he does not know Jane’s disposition as you do.”

“But if a woman is partial to a man, and does not endeavor to conceal
it, he must find it out.”

“Perhaps he must, if he sees enough of her. But though Bingley and Jane
meet tolerably often, it is never for many hours together; and as they
always see each other in large mixed parties, it is impossible that
every moment should be employed in conversing together. Jane should
therefore make the most of every half hour in which she can command his
attention. When she is secure of him, there will be leisure for falling
in love as much as she chooses.”

“Your plan is a good one,” replied Elizabeth, “where nothing is in
question but the desire of being well married; and if I were determined
to get a rich husband, or any husband, I dare say I should adopt it. But
these are not Jane’s feelings; she is not acting by design. As yet she
cannot even be certain of the degree of her own regard, nor of its
reasonableness. She has known him only a fortnight. She danced four
dances with him at Meryton; she saw him one morning at his own house,
and has since dined in company with him four times. This is not quite
enough to make her understand his character.”

“Not as you represent it. Had she merely _dined_ with him, she might
only have discovered whether he had a good appetite; but you must
remember that four evenings have been also spent together--and four
evenings may do a great deal.”

“Yes: these four evenings have enabled them to ascertain that they both
like Vingt-un better than Commerce, but with respect to any other
leading characteristic, I do not imagine that much has been unfolded.”

“Well,” said Charlotte, “I wish Jane success with all my heart; and if
she were married to him to-morrow, I should think she had as good a
chance of happiness as if she were to be studying his character for a
twelvemonth. Happiness in marriage is entirely a matter of chance. If
the dispositions of the parties are ever so well known to each other, or
ever so similar beforehand, it does not advance their felicity in the
least. They always continue to grow sufficiently unlike afterwards to
have their share of vexation; and it is better to know as little as
possible of the defects of the person with whom you are to pass your
life.”

“You make me laugh, Charlotte; but it is not sound. You know it is not
sound, and that you would never act in this way yourself.”

Occupied in observing Mr. Bingley’s attention to her sister, Elizabeth
was far from suspecting that she was herself becoming an object of some
interest in the eyes of his friend. Mr. Darcy had at first scarcely
allowed her to be pretty: he had looked at her without admiration at the
ball; and when they next met, he looked at her only to criticise. But no
sooner had he made it clear to himself and his friends that she had
hardly a good feature in her face, than he began to find it was rendered
uncommonly intelligent by the beautiful expression of her dark eyes. To
this discovery succeeded some others equally mortifying. Though he had
detected with a critical eye more than one failure of perfect symmetry
in her form, he was forced to acknowledge her figure to be light and
pleasing; and in spite of his asserting that her manners were not those
of the fashionable world, he was caught by their easy playfulness. Of
this she was perfectly unaware: to her he was only the man who made
himself agreeable nowhere, and who had not thought her handsome enough
to dance with.

He began to wish to know more of her; and, as a step towards conversing
with her himself, attended to her conversation with others. His doing so
drew her notice. It was at Sir William Lucas’s, where a large party were
assembled.

“What does Mr. Darcy mean,” said she to Charlotte, “by listening to my
conversation with Colonel Forster?”

“That is a question which Mr. Darcy only can answer.”

“But if he does it any more, I shall certainly let him know that I see
what he is about. He has a very satirical eye, and if I do not begin by
being impertinent myself, I shall soon grow afraid of him.”

[Illustration: “The entreaties of several” [_Copyright 1894 by George
Allen._]]

On his approaching them soon afterwards, though without seeming to have
any intention of speaking, Miss Lucas defied her friend to mention such
a subject to him, which immediately provoking Elizabeth to do it, she
turned to him and said,--

“Did not you think, Mr. Darcy, that I expressed myself uncommonly well
just now, when I was teasing Colonel Forster to give us a ball at
Meryton?”

“With great energy; but it is a subject which always makes a lady
energetic.”

“You are severe on us.”

“It will be _her_ turn soon to be teased,” said Miss Lucas. “I am going
to open the instrument, Eliza, and you know what follows.”

“You are a very strange creature by way of a friend!--always wanting me
to play and sing before anybody and everybody! If my vanity had taken a
musical turn, you would have been invaluable; but as it is, I would
really rather not sit down before those who must be in the habit of
hearing the very best performers.” On Miss Lucas’s persevering, however,
she added, “Very well; if it must be so, it must.” And gravely glancing
at Mr. Darcy, “There is a very fine old saying, which everybody here is
of course familiar with--‘Keep your breath to cool your porridge,’--and
I shall keep mine to swell my song.”

Her performance was pleasing, though by no means capital. After a song
or two, and before she could reply to the entreaties of several that she
would sing again, she was eagerly succeeded at the instrument by her
sister Mary, who having, in consequence of being the only plain one in
the family, worked hard for knowledge and accomplishments, was always
impatient for display.

Mary had neither genius nor taste; and though vanity had given her
application, it had given her likewise a pedantic air and conceited
manner, which would have injured a higher degree of excellence than she
had reached. Elizabeth, easy and unaffected, had been listened to with
much more pleasure, though not playing half so well; and Mary, at the
end of a long concerto, was glad to purchase praise and gratitude by
Scotch and Irish airs, at the request of her younger sisters, who with
some of the Lucases, and two or three officers, joined eagerly in
dancing at one end of the room.

Mr. Darcy stood near them in silent indignation at such a mode of
passing the evening, to the exclusion of all conversation, and was too
much engrossed by his own thoughts to perceive that Sir William Lucas
was his neighbour, till Sir William thus began:--

“What a charming amusement for young people this is, Mr. Darcy! There is
nothing like dancing, after all. I consider it as one of the first
refinements of polished societies.”

“Certainly, sir; and it has the advantage also of being in vogue amongst
the less polished societies of the world: every savage can dance.”

Sir William only smiled. “Your friend performs delightfully,” he
continued, after a pause, on seeing Bingley join the group; “and I doubt
not that you are an adept in the science yourself, Mr. Darcy.”

“You saw me dance at Meryton, I believe, sir.”

“Yes, indeed, and received no inconsiderable pleasure from the sight. Do
you often dance at St. James’s?”

“Never, sir.”

“Do you not think it would be a proper compliment to the place?”

“It is a compliment which I never pay to any place if I can avoid it.”

“You have a house in town, I conclude?”

Mr. Darcy bowed.

“I had once some thoughts of fixing in town myself, for I am fond of
superior society; but I did not feel quite certain that the air of
London would agree with Lady Lucas.”

He paused in hopes of an answer: but his companion was not disposed to
make any; and Elizabeth at that instant moving towards them, he was
struck with the notion of doing a very gallant thing, and called out to
her,--

“My dear Miss Eliza, why are not you dancing? Mr. Darcy, you must allow
me to present this young lady to you as a very desirable partner. You
cannot refuse to dance, I am sure, when so much beauty is before you.”
And, taking her hand, he would have given it to Mr. Darcy, who, though
extremely surprised, was not unwilling to receive it, when she instantly
drew back, and said with some discomposure to Sir William,--

“Indeed, sir, I have not the least intention of dancing. I entreat you
not to suppose that I moved this way in order to beg for a partner.”

Mr. Darcy, with grave propriety, requested to be allowed the honour of
her hand, but in vain. Elizabeth was determined; nor did Sir William at
all shake her purpose by his attempt at persuasion.

“You excel so much in the dance, Miss Eliza, that it is cruel to deny me
the happiness of seeing you; and though this gentleman dislikes the
amusement in general, he can have no objection, I am sure, to oblige us
for one half hour.”

“Mr. Darcy is all politeness,” said Elizabeth, smiling.

“He is, indeed: but considering the inducement, my dear Miss Eliza, we
cannot wonder at his complaisance; for who would object to such a
partner?”

Elizabeth looked archly, and turned away. Her resistance had not injured
her with the gentleman, and he was thinking of her with some
complacency, when thus accosted by Miss Bingley,--

“I can guess the subject of your reverie.”

“I should imagine not.”

“You are considering how insupportable it would be to pass many
evenings in this manner,--in such society; and, indeed, I am quite of
your opinion. I was never more annoyed! The insipidity, and yet the
noise--the nothingness, and yet the self-importance, of all these
people! What would I give to hear your strictures on them!”

“Your conjecture is totally wrong, I assure you. My mind was more
agreeably engaged. I have been meditating on the very great pleasure
which a pair of fine eyes in the face of a pretty woman can bestow.”

Miss Bingley immediately fixed her eyes on his face, and desired he
would tell her what lady had the credit of inspiring such reflections.
Mr. Darcy replied, with great intrepidity,--

“Miss Elizabeth Bennet.”

“Miss Elizabeth Bennet!” repeated Miss Bingley. “I am all astonishment.
How long has she been such a favourite? and pray when am I to wish you
joy?”

“That is exactly the question which I expected you to ask. A lady’s
imagination is very rapid; it jumps from admiration to love, from love
to matrimony, in a moment. I knew you would be wishing me joy.”

“Nay, if you are so serious about it, I shall consider the matter as
absolutely settled. You will have a charming mother-in-law, indeed, and
of course she will be always at Pemberley with you.”

He listened to her with perfect indifference, while she chose to
entertain herself in this manner; and as his composure convinced her
that all was safe, her wit flowed along.

[Illustration:

     “A note for Miss Bennet”

[_Copyright 1894 by George Allen._]]

CHAPTER VII.

[Illustration]

Mr. Bennet’s property consisted almost entirely in an estate of two
thousand a year, which, unfortunately for his daughters, was entailed,
in default of heirs male, on a distant relation; and their mother’s
fortune, though ample for her situation in life, could but ill supply
the deficiency of his. Her father had been an attorney in Meryton, and
had left her four thousand pounds.

She had a sister married to a Mr. Philips, who had been a clerk to their
father and succeeded him in the business, and a brother settled in
London in a respectable line of trade.

The village of Longbourn was only one mile from Meryton; a most
convenient distance for the young ladies, who were usually tempted
thither three or four times a week, to pay their duty to their aunt, and
to a milliner’s shop just over the way. The two youngest of the family,
Catherine and Lydia, were particularly frequent in these attentions:
their minds were more vacant than their sisters’, and when nothing
better offered, a walk to Meryton was necessary to amuse their morning
hours and furnish conversation for the evening; and, however bare of
news the country in general might be, they always contrived to learn
some from their aunt. At present, indeed, they were well supplied both
with news and happiness by the recent arrival of a militia regiment in
the neighbourhood; it was to remain the whole winter, and Meryton was
the head-quarters.

Their visits to Mrs. Philips were now productive of the most interesting
intelligence. Every day added something to their knowledge of the
officers’ names and connections. Their lodgings were not long a secret,
and at length they began to know the officers themselves. Mr. Philips
visited them all, and this opened to his nieces a source of felicity
unknown before. They could talk of nothing but officers; and Mr.
Bingley’s large fortune, the mention of which gave animation to their
mother, was worthless in their eyes when opposed to the regimentals of
an ensign.

After listening one morning to their effusions on this subject, Mr.
Bennet coolly observed,--

“From all that I can collect by your manner of talking, you must be two
of the silliest girls in the country. I have suspected it some time, but
I am now convinced.”

Catherine was disconcerted, and made no answer; but Lydia, with perfect
indifference, continued to express her admiration of Captain Carter, and
her hope of seeing him in the course of the day, as he was going the
next morning to London.

“I am astonished, my dear,” said Mrs. Bennet, “that you should be so
ready to think your own children silly. If I wished to think slightingly
of anybody’s children, it should not be of my own, however.”

“If my children are silly, I must hope to be always sensible of it.”

“Yes; but as it happens, they are all of them very clever.”

“This is the only point, I flatter myself, on which we do not agree. I
had hoped that our sentiments coincided in every particular, but I must
so far differ from you as to think our two youngest daughters uncommonly
foolish.”

“My dear Mr. Bennet, you must not expect such girls to have the sense of
their father and mother. When they get to our age, I dare say they will
not think about officers any more than we do. I remember the time when I
liked a red coat myself very well--and, indeed, so I do still at my
heart; and if a smart young colonel, with five or six thousand a year,
should want one of my girls, I shall not say nay to him; and I thought
Colonel Forster looked very becoming the other night at Sir William’s in
his regimentals.”

“Mamma,” cried Lydia, “my aunt says that Colonel Forster and Captain
Carter do not go so often to Miss Watson’s as they did when they first
came; she sees them now very often standing in Clarke’s library.”

Mrs. Bennet was prevented replying by the entrance of the footman with a
note for Miss Bennet; it came from Netherfield, and the servant waited
for an answer. Mrs. Bennet’s eyes sparkled with pleasure, and she was
eagerly calling out, while her daughter read,--

“Well, Jane, who is it from? What is it about? What does he say? Well,
Jane, make haste and tell us; make haste, my love.”

“It is from Miss Bingley,” said Jane, and then read it aloud.

     /* NIND “My dear friend, */

     “If you are not so compassionate as to dine to-day with Louisa and
     me, we shall be in danger of hating each other for the rest of our
     lives; for a whole day’s _tête-à-tête_ between two women can never
     end without a quarrel. Come as soon as you can on the receipt of
     this. My brother and the gentlemen are to dine with the officers.
     Yours ever,

“CAROLINE BINGLEY.”

“With the officers!” cried Lydia: “I wonder my aunt did not tell us of
_that_.”

“Dining out,” said Mrs. Bennet; “that is very unlucky.”

“Can I have the carriage?” said Jane.

“No, my dear, you had better go on horseback, because it seems likely to
rain; and then you must stay all night.”

“That would be a good scheme,” said Elizabeth, “if you were sure that
they would not offer to send her home.”

“Oh, but the gentlemen will have Mr. Bingley’s chaise to go to Meryton;
and the Hursts have no horses to theirs.”

“I had much rather go in the coach.”

“But, my dear, your father cannot spare the horses, I am sure. They are
wanted in the farm, Mr. Bennet, are not they?”

[Illustration: Cheerful prognostics]

“They are wanted in the farm much oftener than I can get them.”

“But if you have got them to-day,” said Elizabeth, “my mother’s purpose
will be answered.”

She did at last extort from her father an acknowledgment that the horses
were engaged; Jane was therefore obliged to go on horseback, and her
mother attended her to the door with many cheerful prognostics of a bad
day. Her hopes were answered; Jane had not been gone long before it
rained hard. Her sisters were uneasy for her, but her mother was
delighted. The rain continued the whole evening without intermission;
Jane certainly could not come back.

“This was a lucky idea of mine, indeed!” said Mrs. Bennet, more than
once, as if the credit of making it rain were all her own. Till the next
morning, however, she was not aware of all the felicity of her
contrivance. Breakfast was scarcely over when a servant from Netherfield
brought the following note for Elizabeth:--

     /* NIND “My dearest Lizzie, */

     “I find myself very unwell this morning, which, I suppose, is to be
     imputed to my getting wet through yesterday. My kind friends will
     not hear of my returning home till I am better. They insist also on
     my seeing Mr. Jones--therefore do not be alarmed if you should hear
     of his having been to me--and, excepting a sore throat and a
     headache, there is not much the matter with me.

“Yours, etc.”

“Well, my dear,” said Mr. Bennet, when Elizabeth had read the note
aloud, “if your daughter should have a dangerous fit of illness--if she
should die--it would be a comfort to know that it was all in pursuit of
Mr. Bingley, and under your orders.”

“Oh, I am not at all afraid of her dying. People do not die of little
trifling colds. She will be taken good care of. As long as she stays
there, it is all very well. I would go and see her if I could have the
carriage.”

Elizabeth, feeling really anxious, determined to go to her, though the
carriage was not to be had: and as she was no horsewoman, walking was
her only alternative. She declared her resolution.

“How can you be so silly,” cried her mother, “as to think of such a
thing, in all this dirt! You will not be fit to be seen when you get
there.”

“I shall be very fit to see Jane--which is all I want.”

“Is this a hint to me, Lizzy,” said her father, “to send for the
horses?”

“No, indeed. I do not wish to avoid the walk. The distance is nothing,
when one has a motive; only three miles. I shall be back by dinner.”

“I admire the activity of your benevolence,” observed Mary, “but every
impulse of feeling should be guided by reason; and, in my opinion,
exertion should always be in proportion to what is required.”

“We will go as far as Meryton with you,” said Catherine and Lydia.
Elizabeth accepted their company, and the three young ladies set off
together.

“If we make haste,” said Lydia, as they walked along, “perhaps we may
see something of Captain Carter, before he goes.”

In Meryton they parted: the two youngest repaired to the lodgings of one
of the officers’ wives, and Elizabeth continued her walk alone, crossing
field after field at a quick pace, jumping over stiles and springing
over puddles, with impatient activity, and finding herself at last
within view of the house, with weary ancles, dirty stockings, and a face
glowing with the warmth of exercise.

She was shown into the breakfast parlour, where all but Jane were
assembled, and where her appearance created a great deal of surprise.
That she should have walked three miles so early in the day in such
dirty weather, and by herself, was almost incredible to Mrs. Hurst and
Miss Bingley; and Elizabeth was convinced that they held her in contempt
for it. She was received, however, very politely by them; and in their
brother’s manners there was something better than politeness--there was
good-humour and kindness. Mr. Darcy said very little, and Mr. Hurst
nothing at all. The former was divided between admiration of the
brilliancy which exercise had given to her complexion and doubt as to
the occasion’s justifying her coming so far alone. The latter was
thinking only of his breakfast.

Her inquiries after her sister were not very favourably answered. Miss
Bennet had slept ill, and though up, was very feverish, and not well
enough to leave her room. Elizabeth was glad to be taken to her
immediately; and Jane, who had only been withheld by the fear of giving
alarm or inconvenience, from expressing in her note how much she longed
for such a visit, was delighted at her entrance. She was not equal,
however, to much conversation; and when Miss Bingley left them together,
could attempt little beside expressions of gratitude for the
extraordinary kindness she was treated with. Elizabeth silently attended
her.

When breakfast was over, they were joined by the sisters; and Elizabeth
began to like them herself, when she saw how much affection and
solicitude they showed for Jane. The apothecary came; and having
examined his patient, said, as might be supposed, that she had caught a
violent cold, and that they must endeavour to get the better of it;
advised her to return to bed, and promised her some draughts. The advice
was followed readily, for the feverish symptoms increased, and her head
ached acutely. Elizabeth did not quit her room for a moment, nor were
the other ladies often absent; the gentlemen being out, they had in fact
nothing to do elsewhere.

When the clock struck three, Elizabeth felt that she must go, and very
unwillingly said so. Miss Bingley offered her the carriage, and she only
wanted a little pressing to accept it, when Jane testified such concern
at parting with her that Miss Bingley was obliged to convert the offer
of the chaise into an invitation to remain at Netherfield for the
present. Elizabeth most thankfully consented, and a servant was
despatched to Longbourn, to acquaint the family with her stay, and bring
back a supply of clothes.

[Illustration:

“The Apothecary came”
]

[Illustration:

“covering a screen”
]

CHAPTER VIII.

[Illustration]

At five o’clock the two ladies retired to dress, and at half-past six
Elizabeth was summoned to dinner. To the civil inquiries which then
poured in, and amongst which she had the pleasure of distinguishing the
much superior solicitude of Mr. Bingley, she could not make a very
favourable answer. Jane was by no means better. The sisters, on hearing
this, repeated three or four times how much they were grieved, how
shocking it was to have a bad cold, and how excessively they disliked
being ill themselves; and then thought no more of the matter: and their
indifference towards Jane, when not immediately before them, restored
Elizabeth to the enjoyment of all her original dislike.

Their brother, indeed, was the only one of the party whom she could
regard with any complacency. His anxiety for Jane was evident, and his
attentions to herself most pleasing; and they prevented her feeling
herself so much an intruder as she believed she was considered by the
others. She had very little notice from any but him. Miss Bingley was
engrossed by Mr. Darcy, her sister scarcely less so; and as for Mr.
Hurst, by whom Elizabeth sat, he was an indolent man, who lived only to
eat, drink, and play at cards, who, when he found her prefer a plain
dish to a ragout, had nothing to say to her.

When dinner was over, she returned directly to Jane, and Miss Bingley
began abusing her as soon as she was out of the room. Her manners were
pronounced to be very bad indeed,--a mixture of pride and impertinence:
she had no conversation, no style, no taste, no beauty. Mrs. Hurst
thought the same, and added,--

“She has nothing, in short, to recommend her, but being an excellent
walker. I shall never forget her appearance this morning. She really
looked almost wild.”

“She did indeed, Louisa. I could hardly keep my countenance. Very
nonsensical to come at all! Why must _she_ be scampering about the
country, because her sister had a cold? Her hair so untidy, so blowzy!”

“Yes, and her petticoat; I hope you saw her petticoat, six inches deep
in mud, I am absolutely certain, and the gown which had been let down to
hide it not doing its office.”

“Your picture may be very exact, Louisa,” said Bingley; “but this was
all lost upon me. I thought Miss Elizabeth Bennet looked remarkably well
when she came into the room this morning. Her dirty petticoat quite
escaped my notice.”

“_You_ observed it, Mr. Darcy, I am sure,” said Miss Bingley; “and I am
inclined to think that you would not wish to see _your sister_ make such
an exhibition.”

“Certainly not.”

“To walk three miles, or four miles, or five miles, or whatever it is,
above her ancles in dirt, and alone, quite alone! what could she mean by
it? It seems to me to show an abominable sort of conceited independence,
a most country-town indifference to decorum.”

“It shows an affection for her sister that is very pleasing,” said
Bingley.

“I am afraid, Mr. Darcy,” observed Miss Bingley, in a half whisper,
“that this adventure has rather affected your admiration of her fine
eyes.”

“Not at all,” he replied: “they were brightened by the exercise.” A
short pause followed this speech, and Mrs. Hurst began again,--

“I have an excessive regard for Jane Bennet,--she is really a very sweet
girl,--and I wish with all my heart she were well settled. But with such
a father and mother, and such low connections, I am afraid there is no
chance of it.”

“I think I have heard you say that their uncle is an attorney in
Meryton?”

“Yes; and they have another, who lives somewhere near Cheapside.”

“That is capital,” added her sister; and they both laughed heartily.

“If they had uncles enough to fill _all_ Cheapside,” cried Bingley, “it
would not make them one jot less agreeable.”

“But it must very materially lessen their chance of marrying men of any
consideration in the world,” replied Darcy.

To this speech Bingley made no answer; but his sisters gave it their
hearty assent, and indulged their mirth for some time at the expense of
their dear friend’s vulgar relations.

With a renewal of tenderness, however, they repaired to her room on
leaving the dining-parlour, and sat with her till summoned to coffee.
She was still very poorly, and Elizabeth would not quit her at all, till
late in the evening, when she had the comfort of seeing her asleep, and
when it appeared to her rather right than pleasant that she should go
down stairs herself. On entering the drawing-room, she found the whole
party at loo, and was immediately invited to join them; but suspecting
them to be playing high, she declined it, and making her sister the
excuse, said she would amuse herself, for the short time she could stay
below, with a book. Mr. Hurst looked at her with astonishment.

“Do you prefer reading to cards?” said he; “that is rather singular.”

“Miss Eliza Bennet,” said Miss Bingley, “despises cards. She is a great
reader, and has no pleasure in anything else.”

“I deserve neither such praise nor such censure,” cried Elizabeth; “I
am _not_ a great reader, and I have pleasure in many things.”

“In nursing your sister I am sure you have pleasure,” said Bingley; “and
I hope it will soon be increased by seeing her quite well.”

Elizabeth thanked him from her heart, and then walked towards a table
where a few books were lying. He immediately offered to fetch her
others; all that his library afforded.

“And I wish my collection were larger for your benefit and my own
credit; but I am an idle fellow; and though I have not many, I have more
than I ever looked into.”

Elizabeth assured him that she could suit herself perfectly with those
in the room.

“I am astonished,” said Miss Bingley, “that my father should have left
so small a collection of books. What a delightful library you have at
Pemberley, Mr. Darcy!”

“It ought to be good,” he replied: “it has been the work of many
generations.”

“And then you have added so much to it yourself--you are always buying
books.”

“I cannot comprehend the neglect of a family library in such days as
these.”

“Neglect! I am sure you neglect nothing that can add to the beauties of
that noble place. Charles, when you build _your_ house, I wish it may be
half as delightful as Pemberley.”

“I wish it may.”

“But I would really advise you to make your purchase in that
neighbourhood, and take Pemberley for a kind of model. There is not a
finer county in England than Derbyshire.”

“With all my heart: I will buy Pemberley itself, if Darcy will sell it.”

“I am talking of possibilities, Charles.”

“Upon my word, Caroline, I should think it more possible to get
Pemberley by purchase than by imitation.”

Elizabeth was so much caught by what passed, as to leave her very little
attention for her book; and, soon laying it wholly aside, she drew near
the card-table, and stationed herself between Mr. Bingley and his eldest
sister, to observe the game.

“Is Miss Darcy much grown since the spring?” said Miss Bingley: “will
she be as tall as I am?”

“I think she will. She is now about Miss Elizabeth Bennet’s height, or
rather taller.”

“How I long to see her again! I never met with anybody who delighted me
so much. Such a countenance, such manners, and so extremely accomplished
for her age! Her performance on the pianoforte is exquisite.”

“It is amazing to me,” said Bingley, “how young ladies can have patience
to be so very accomplished as they all are.”

“All young ladies accomplished! My dear Charles, what do you mean?”

“Yes, all of them, I think. They all paint tables, cover screens, and
net purses. I scarcely know any one who cannot do all this; and I am
sure I never heard a young lady spoken of for the first time, without
being informed that she was very accomplished.”

“Your list of the common extent of accomplishments,” said Darcy, “has
too much truth. The word is applied to many a woman who deserves it no
otherwise than by netting a purse or covering a screen; but I am very
far from agreeing with you in your estimation of ladies in general. I
cannot boast of knowing more than half-a-dozen in the whole range of my
acquaintance that are really accomplished.”

“Nor I, I am sure,” said Miss Bingley.

“Then,” observed Elizabeth, “you must comprehend a great deal in your
idea of an accomplished woman.”

“Yes; I do comprehend a great deal in it.”

“Oh, certainly,” cried his faithful assistant, “no one can be really
esteemed accomplished who does not greatly surpass what is usually met
with. A woman must have a thorough knowledge of music, singing, drawing,
dancing, and the modern languages, to deserve the word; and, besides all
this, she must possess a certain something in her air and manner of
walking, the tone of her voice, her address and expressions, or the word
will be but half deserved.”

“All this she must possess,” added Darcy; “and to all she must yet add
something more substantial in the improvement of her mind by extensive
reading.”

“I am no longer surprised at your knowing _only_ six accomplished women.
I rather wonder now at your knowing _any_.”

“Are you so severe upon your own sex as to doubt the possibility of all
this?”

“_I_ never saw such a woman. _I_ never saw such capacity, and taste, and
application, and elegance, as you describe, united.”

Mrs. Hurst and Miss Bingley both cried out against the injustice of her
implied doubt, and were both protesting that they knew many women who
answered this description, when Mr. Hurst called them to order, with
bitter complaints of their inattention to what was going forward. As all
conversation was thereby at an end, Elizabeth soon afterwards left the
room.

“Eliza Bennet,” said Miss Bingley, when the door was closed on her, “is
one of those young ladies who seek to recommend themselves to the other
sex by undervaluing their own; and with many men, I daresay, it
succeeds; but, in my opinion, it is a paltry device, a very mean art.”

“Undoubtedly,” replied Darcy, to whom this remark was chiefly addressed,
“there is meanness in _all_ the arts which ladies sometimes condescend
to employ for captivation. Whatever bears affinity to cunning is
despicable.”

Miss Bingley was not so entirely satisfied with this reply as to
continue the subject.

Elizabeth joined them again only to say that her sister was worse, and
that she could not leave her. Bingley urged Mr. Jones’s being sent for
immediately; while his sisters, convinced that no country advice could
be of any service, recommended an express to town for one of the most
eminent physicians. This she would not hear of; but she was not so
unwilling to comply with their brother’s proposal; and it was settled
that Mr. Jones should be sent for early in the morning, if Miss Bennet
were not decidedly better. Bingley was quite uncomfortable; his sisters
declared that they were miserable. They solaced their wretchedness,
however, by duets after supper; while he could find no better relief to
his feelings than by giving his housekeeper directions that every
possible attention might be paid to the sick lady and her sister.

[Illustration:

M^{rs} Bennet and her two youngest girls

[_Copyright 1894 by George Allen._]]

CHAPTER IX.

[Illustration]

Elizabeth passed the chief of the night in her sister’s room, and in the
morning had the pleasure of being able to send a tolerable answer to the
inquiries which she very early received from Mr. Bingley by a housemaid,
and some time afterwards from the two elegant ladies who waited on his
sisters. In spite of this amendment, however, she requested to have a
note sent to Longbourn, desiring her mother to visit Jane, and form her
own judgment of her situation. The note was immediately despatched, and
its contents as quickly complied with. Mrs. Bennet, accompanied by her
two youngest girls, reached Netherfield soon after the family breakfast.

Had she found Jane in any apparent danger, Mrs. Bennet would have been
very miserable; but being satisfied on seeing her that her illness was
not alarming, she had no wish of her recovering immediately, as her
restoration to health would probably remove her from Netherfield. She
would not listen, therefore, to her daughter’s proposal of being carried
home; neither did the apothecary, who arrived about the same time, think
it at all advisable. After sitting a little while with Jane, on Miss
Bingley’s appearance and invitation, the mother and three daughters all
attended her into the breakfast parlour. Bingley met them with hopes
that Mrs. Bennet had not found Miss Bennet worse than she expected.

“Indeed I have, sir,” was her answer. “She is a great deal too ill to be
moved. Mr. Jones says we must not think of moving her. We must trespass
a little longer on your kindness.”

“Removed!” cried Bingley. “It must not be thought of. My sister, I am
sure, will not hear of her removal.”

“You may depend upon it, madam,” said Miss Bingley, with cold civility,
“that Miss Bennet shall receive every possible attention while she
remains with us.”

Mrs. Bennet was profuse in her acknowledgments.

“I am sure,” she added, “if it was not for such good friends, I do not
know what would become of her, for she is very ill indeed, and suffers a
vast deal, though with the greatest patience in the world, which is
always the way with her, for she has, without exception, the sweetest
temper I ever met with. I often tell my other girls they are nothing to
_her_. You have a sweet room here, Mr. Bingley, and a charming prospect
over that gravel walk. I do not know a place in the country that is
equal to Netherfield. You will not think of quitting it in a hurry, I
hope, though you have but a short lease.”

“Whatever I do is done in a hurry,” replied he; “and therefore if I
should resolve to quit Netherfield, I should probably be off in five
minutes. At present, however, I consider myself as quite fixed here.”

“That is exactly what I should have supposed of you,” said Elizabeth.

“You begin to comprehend me, do you?” cried he, turning towards her.

“Oh yes--I understand you perfectly.”

“I wish I might take this for a compliment; but to be so easily seen
through, I am afraid, is pitiful.”

“That is as it happens. It does not necessarily follow that a deep,
intricate character is more or less estimable than such a one as yours.”

“Lizzy,” cried her mother, “remember where you are, and do not run on in
the wild manner that you are suffered to do at home.”

“I did not know before,” continued Bingley, immediately, “that you were
a studier of character. It must be an amusing study.”

“Yes; but intricate characters are the _most_ amusing. They have at
least that advantage.”

“The country,” said Darcy, “can in general supply but few subjects for
such a study. In a country neighbourhood you move in a very confined and
unvarying society.”

“But people themselves alter so much, that there is something new to be
observed in them for ever.”

“Yes, indeed,” cried Mrs. Bennet, offended by his manner of mentioning a
country neighbourhood. “I assure you there is quite as much of _that_
going on in the country as in town.”

Everybody was surprised; and Darcy, after looking at her for a moment,
turned silently away. Mrs. Bennet, who fancied she had gained a complete
victory over him, continued her triumph,--

“I cannot see that London has any great advantage over the country, for
my part, except the shops and public places. The country is a vast deal
pleasanter, is not it, Mr. Bingley?”

“When I am in the country,” he replied, “I never wish to leave it; and
when I am in town, it is pretty much the same. They have each their
advantages, and I can be equally happy in either.”

“Ay, that is because you have the right disposition. But that
gentleman,” looking at Darcy, “seemed to think the country was nothing
at all.”

“Indeed, mamma, you are mistaken,” said Elizabeth, blushing for her
mother. “You quite mistook Mr. Darcy. He only meant that there was not
such a variety of people to be met with in the country as in town, which
you must acknowledge to be true.”

“Certainly, my dear, nobody said there were; but as to not meeting with
many people in this neighbourhood, I believe there are few
neighbourhoods larger. I know we dine with four-and-twenty families.”

Nothing but concern for Elizabeth could enable Bingley to keep his
countenance. His sister was less delicate, and directed her eye towards
Mr. Darcy with a very expressive smile. Elizabeth, for the sake of
saying something that might turn her mother’s thoughts, now asked her if
Charlotte Lucas had been at Longbourn since _her_ coming away.

“Yes, she called yesterday with her father. What an agreeable man Sir
William is, Mr. Bingley--is not he? so much the man of fashion! so
genteel and so easy! He has always something to say to everybody. _That_
is my idea of good breeding; and those persons who fancy themselves very
important and never open their mouths quite mistake the matter.”

“Did Charlotte dine with you?”

“No, she would go home. I fancy she was wanted about the mince-pies. For
my part, Mr. Bingley, _I_ always keep servants that can do their own
work; _my_ daughters are brought up differently. But everybody is to
judge for themselves, and the Lucases are a very good sort of girls, I
assure you. It is a pity they are not handsome! Not that _I_ think
Charlotte so _very_ plain; but then she is our particular friend.”

“She seems a very pleasant young woman,” said Bingley.

“Oh dear, yes; but you must own she is very plain. Lady Lucas herself
has often said so, and envied me Jane’s beauty. I do not like to boast
of my own child; but to be sure, Jane--one does not often see anybody
better looking. It is what everybody says. I do not trust my own
partiality. When she was only fifteen there was a gentleman at my
brother Gardiner’s in town so much in love with her, that my
sister-in-law was sure he would make her an offer before we came away.
But, however, he did not. Perhaps he thought her too young. However, he
wrote some verses on her, and very pretty they were.”

“And so ended his affection,” said Elizabeth, impatiently. “There has
been many a one, I fancy, overcome in the same way. I wonder who first
discovered the efficacy of poetry in driving away love!”

“I have been used to consider poetry as the _food_ of love,” said Darcy.

“Of a fine, stout, healthy love it may. Everything nourishes what is
strong already. But if it be only a slight, thin sort of inclination, I
am convinced that one good sonnet will starve it entirely away.”

Darcy only smiled; and the general pause which ensued made Elizabeth
tremble lest her mother should be exposing herself again. She longed to
speak, but could think of nothing to say; and after a short silence Mrs.
Bennet began repeating her thanks to Mr. Bingley for his kindness to
Jane, with an apology for troubling him also with Lizzy. Mr. Bingley was
unaffectedly civil in his answer, and forced his younger sister to be
civil also, and say what the occasion required. She performed her part,
indeed, without much graciousness, but Mrs. Bennet was satisfied, and
soon afterwards ordered her carriage. Upon this signal, the youngest of
her daughters put herself forward. The two girls had been whispering to
each other during the whole visit; and the result of it was, that the
youngest should tax Mr. Bingley with having promised on his first coming
into the country to give a ball at Netherfield.

Lydia was a stout, well-grown girl of fifteen, with a fine complexion
and good-humoured countenance; a favourite with her mother, whose
affection had brought her into public at an early age. She had high
animal spirits, and a sort of natural self-consequence, which the
attentions of the officers, to whom her uncle’s good dinners and her
own easy manners recommended her, had increased into assurance. She was
very equal, therefore, to address Mr. Bingley on the subject of the
ball, and abruptly reminded him of his promise; adding, that it would be
the most shameful thing in the world if he did not keep it. His answer
to this sudden attack was delightful to her mother’s ear.

“I am perfectly ready, I assure you, to keep my engagement; and, when
your sister is recovered, you shall, if you please, name the very day of
the ball. But you would not wish to be dancing while she is ill?”

Lydia declared herself satisfied. “Oh yes--it would be much better to
wait till Jane was well; and by that time, most likely, Captain Carter
would be at Meryton again. And when you have given _your_ ball,” she
added, “I shall insist on their giving one also. I shall tell Colonel
Forster it will be quite a shame if he does not.”

Mrs. Bennet and her daughters then departed, and Elizabeth returned
instantly to Jane, leaving her own and her relations’ behaviour to the
remarks of the two ladies and Mr. Darcy; the latter of whom, however,
could not be prevailed on to join in their censure of _her_, in spite of
all Miss Bingley’s witticisms on _fine eyes_.

[Illustration]

CHAPTER X.

[Illustration]

The day passed much as the day before had done. Mrs. Hurst and Miss
Bingley had spent some hours of the morning with the invalid, who
continued, though slowly, to mend; and, in the evening, Elizabeth joined
their party in the drawing-room. The loo table, however, did not appear.
Mr. Darcy was writing, and Miss Bingley, seated near him, was watching
the progress of his letter, and repeatedly calling off his attention by
messages to his sister. Mr. Hurst and Mr. Bingley were at piquet, and
Mrs. Hurst was observing their game.

Elizabeth took up some needlework, and was sufficiently amused in
attending to what passed between Darcy and his companion. The perpetual
commendations of the lady either on his hand-writing, or on the evenness
of his lines, or on the length of his letter, with the perfect unconcern
with which her praises were received, formed a curious dialogue, and was
exactly in unison with her opinion of each.

“How delighted Miss Darcy will be to receive such a letter!”

He made no answer.

“You write uncommonly fast.”

“You are mistaken. I write rather slowly.”

“How many letters you must have occasion to write in the course of a
year! Letters of business, too! How odious I should think them!”

“It is fortunate, then, that they fall to my lot instead of to yours.”

“Pray tell your sister that I long to see her.”

“I have already told her so once, by your desire.”

“I am afraid you do not like your pen. Let me mend it for you. I mend
pens remarkably well.”

“Thank you--but I always mend my own.”

“How can you contrive to write so even?”

He was silent.

“Tell your sister I am delighted to hear of her improvement on the harp,
and pray let her know that I am quite in raptures with her beautiful
little design for a table, and I think it infinitely superior to Miss
Grantley’s.”

“Will you give me leave to defer your raptures till I write again? At
present I have not room to do them justice.”

“Oh, it is of no consequence. I shall see her in January. But do you
always write such charming long letters to her, Mr. Darcy?”

“They are generally long; but whether always charming, it is not for me
to determine.”

“It is a rule with me, that a person who can write a long letter with
ease cannot write ill.”

“That will not do for a compliment to Darcy, Caroline,” cried her
brother, “because he does _not_ write with ease. He studies too much
for words of four syllables. Do not you, Darcy?”

“My style of writing is very different from yours.”

“Oh,” cried Miss Bingley, “Charles writes in the most careless way
imaginable. He leaves out half his words, and blots the rest.”

“My ideas flow so rapidly that I have not time to express them; by which
means my letters sometimes convey no ideas at all to my correspondents.”

“Your humility, Mr. Bingley,” said Elizabeth, “must disarm reproof.”

“Nothing is more deceitful,” said Darcy, “than the appearance of
humility. It is often only carelessness of opinion, and sometimes an
indirect boast.”

“And which of the two do you call _my_ little recent piece of modesty?”

“The indirect boast; for you are really proud of your defects in
writing, because you consider them as proceeding from a rapidity of
thought and carelessness of execution, which, if not estimable, you
think at least highly interesting. The power of doing anything with
quickness is always much prized by the possessor, and often without any
attention to the imperfection of the performance. When you told Mrs.
Bennet this morning, that if you ever resolved on quitting Netherfield
you should be gone in five minutes, you meant it to be a sort of
panegyric, of compliment to yourself; and yet what is there so very
laudable in a precipitance which must leave very necessary business
undone, and can be of no real advantage to yourself or anyone else?”

“Nay,” cried Bingley, “this is too much, to remember at night all the
foolish things that were said in the morning. And yet, upon my honour, I
believed what I said of myself to be true, and I believe it at this
moment. At least, therefore, I did not assume the character of needless
precipitance merely to show off before the ladies.”

“I daresay you believed it; but I am by no means convinced that you
would be gone with such celerity. Your conduct would be quite as
dependent on chance as that of any man I know; and if, as you were
mounting your horse, a friend were to say, ‘Bingley, you had better stay
till next week,’ you would probably do it--you would probably not
go--and, at another word, might stay a month.”

“You have only proved by this,” cried Elizabeth, “that Mr. Bingley did
not do justice to his own disposition. You have shown him off now much
more than he did himself.”

“I am exceedingly gratified,” said Bingley, “by your converting what my
friend says into a compliment on the sweetness of my temper. But I am
afraid you are giving it a turn which that gentleman did by no means
intend; for he would certainly think the better of me if, under such a
circumstance, I were to give a flat denial, and ride off as fast as I
could.”

“Would Mr. Darcy then consider the rashness of your original intention
as atoned for by your obstinacy in adhering to it?”

“Upon my word, I cannot exactly explain the matter--Darcy must speak for
himself.”

“You expect me to account for opinions which you choose to call mine,
but which I have never acknowledged. Allowing the case, however, to
stand according to your representation, you must remember, Miss Bennet,
that the friend who is supposed to desire his return to the house, and
the delay of his plan, has merely desired it, asked it without offering
one argument in favour of its propriety.”

“To yield readily--easily--to the _persuasion_ of a friend is no merit
with you.”

“To yield without conviction is no compliment to the understanding of
either.”

“You appear to me, Mr. Darcy, to allow nothing for the influence of
friendship and affection. A regard for the requester would often make
one readily yield to a request, without waiting for arguments to reason
one into it. I am not particularly speaking of such a case as you have
supposed about Mr. Bingley. We may as well wait, perhaps, till the
circumstance occurs, before we discuss the discretion of his behaviour
thereupon. But in general and ordinary cases, between friend and friend,
where one of them is desired by the other to change a resolution of no
very great moment, should you think ill of that person for complying
with the desire, without waiting to be argued into it?”

“Will it not be advisable, before we proceed on this subject, to arrange
with rather more precision the degree of importance which is to
appertain to this request, as well as the degree of intimacy subsisting
between the parties?”

“By all means,” cried Bingley; “let us hear all the particulars, not
forgetting their comparative height and size, for that will have more
weight in the argument, Miss Bennet, than you may be aware of. I assure
you that if Darcy were not such a great tall fellow, in comparison with
myself, I should not pay him half so much deference. I declare I do not
know a more awful object than Darcy on particular occasions, and in
particular places; at his own house especially, and of a Sunday evening,
when he has nothing to do.”

Mr. Darcy smiled; but Elizabeth thought she could perceive that he was
rather offended, and therefore checked her laugh. Miss Bingley warmly
resented the indignity he had received, in an expostulation with her
brother for talking such nonsense.

“I see your design, Bingley,” said his friend. “You dislike an argument,
and want to silence this.”

“Perhaps I do. Arguments are too much like disputes. If you and Miss
Bennet will defer yours till I am out of the room, I shall be very
thankful; and then you may say whatever you like of me.”

“What you ask,” said Elizabeth, “is no sacrifice on my side; and Mr.
Darcy had much better finish his letter.”

Mr. Darcy took her advice, and did finish his letter.

When that business was over, he applied to Miss Bingley and Elizabeth
for the indulgence of some music. Miss Bingley moved with alacrity to
the pianoforte, and after a polite request that Elizabeth would lead the
way, which the other as politely and more earnestly negatived, she
seated herself.

Mrs. Hurst sang with her sister; and while they were thus employed,
Elizabeth could not help observing, as she turned over some music-books
that lay on the instrument, how frequently Mr. Darcy’s eyes were fixed
on her. She hardly knew how to suppose that she could be an object of
admiration to so great a man, and yet that he should look at her because
he disliked her was still more strange. She could only imagine, however,
at last, that she drew his notice because there was something about her
more wrong and reprehensible, according to his ideas of right, than in
any other person present. The supposition did not pain her. She liked
him too little to care for his approbation.

After playing some Italian songs, Miss Bingley varied the charm by a
lively Scotch air; and soon afterwards Mr. Darcy, drawing near
Elizabeth, said to her,--

“Do you not feel a great inclination, Miss Bennet, to seize such an
opportunity of dancing a reel?”

She smiled, but made no answer. He repeated the question, with some
surprise at her silence.

“Oh,” said she, “I heard you before; but I could not immediately
determine what to say in reply. You wanted me, I know, to say ‘Yes,’
that you might have the pleasure of despising my taste; but I always
delight in overthrowing those kind of schemes, and cheating a person of
their premeditated contempt. I have, therefore, made up my mind to tell
you that I do not want to dance a reel at all; and now despise me if you
dare.”

“Indeed I do not dare.”

Elizabeth, having rather expected to affront him, was amazed at his
gallantry; but there was a mixture of sweetness and archness in her
manner which made it difficult for her to affront anybody, and Darcy had
never been so bewitched by any woman as he was by her. He really
believed that, were it not for the inferiority of her connections, he
should be in some danger.

Miss Bingley saw, or suspected, enough to be jealous; and her great
anxiety for the recovery of her dear friend Jane received some
assistance from her desire of getting rid of Elizabeth.

She often tried to provoke Darcy into disliking her guest, by talking of
their supposed marriage, and planning his happiness in such an alliance.

“I hope,” said she, as they were walking together in the shrubbery the
next day, “you will give your mother-in-law a few hints, when this
desirable event takes place, as to the advantage of holding her tongue;
and if you can compass it, to cure the younger girls of running after
the officers. And, if I may mention so delicate a subject, endeavour to
check that little something, bordering on conceit and impertinence,
which your lady possesses.”

[Illustration:

     “No, no; stay where you are”

[_Copyright 1894 by George Allen._]]

“Have you anything else to propose for my domestic felicity?”

“Oh yes. Do let the portraits of your uncle and aunt Philips be placed
in the gallery at Pemberley. Put them next to your great-uncle the
judge. They are in the same profession, you know, only in different
lines. As for your Elizabeth’s picture, you must not attempt to have it
taken, for what painter could do justice to those beautiful eyes?”

“It would not be easy, indeed, to catch their expression; but their
colour and shape, and the eyelashes, so remarkably fine, might be
copied.”

At that moment they were met from another walk by Mrs. Hurst and
Elizabeth herself.

“I did not know that you intended to walk,” said Miss Bingley, in some
confusion, lest they had been overheard.

“You used us abominably ill,” answered Mrs. Hurst, “running away without
telling us that you were coming out.”

Then taking the disengaged arm of Mr. Darcy, she left Elizabeth to walk
by herself. The path just admitted three. Mr. Darcy felt their rudeness,
and immediately said,--

“This walk is not wide enough for our party. We had better go into the
avenue.”

But Elizabeth, who had not the least inclination to remain with them,
laughingly answered,--

“No, no; stay where you are. You are charmingly grouped, and appear to
uncommon advantage. The picturesque would be spoilt by admitting a
fourth. Good-bye.”

She then ran gaily off, rejoicing, as she rambled about, in the hope of
being at home again in a day or two. Jane was already so much recovered
as to intend leaving her room for a couple of hours that evening.

[Illustration:

     “Piling up the fire”

[_Copyright 1894 by George Allen._]]

CHAPTER XI.

[Illustration]

When the ladies removed after dinner Elizabeth ran up to her sister, and
seeing her well guarded from cold, attended her into the drawing-room,
where she was welcomed by her two friends with many professions of
pleasure; and Elizabeth had never seen them so agreeable as they were
during the hour which passed before the gentlemen appeared. Their powers
of conversation were considerable. They could describe an entertainment
with accuracy, relate an anecdote with humour, and laugh at their
acquaintance with spirit.

But when the gentlemen entered, Jane was no longer the first object;
Miss Bingley’s eyes were instantly turned towards Darcy, and she had
something to say to him before he had advanced many steps. He addressed
himself directly to Miss Bennet with a polite congratulation; Mr. Hurst
also made her a slight bow, and said he was “very glad;” but diffuseness
and warmth remained for Bingley’s salutation. He was full of joy and
attention. The first half hour was spent in piling up the fire, lest she
should suffer from the change of room; and she removed, at his desire,
to the other side of the fireplace, that she might be farther from the
door. He then sat down by her, and talked scarcely to anyone else.
Elizabeth, at work in the opposite corner, saw it all with great
delight.

When tea was over Mr. Hurst reminded his sister-in-law of the
card-table--but in vain. She had obtained private intelligence that Mr.
Darcy did not wish for cards, and Mr. Hurst soon found even his open
petition rejected. She assured him that no one intended to play, and the
silence of the whole party on the subject seemed to justify her. Mr.
Hurst had, therefore, nothing to do but to stretch himself on one of the
sofas and go to sleep. Darcy took up a book. Miss Bingley did the same;
and Mrs. Hurst, principally occupied in playing with her bracelets and
rings, joined now and then in her brother’s conversation with Miss
Bennet.

Miss Bingley’s attention was quite as much engaged in watching Mr.
Darcy’s progress through _his_ book, as in reading her own; and she was
perpetually either making some inquiry, or looking at his page. She
could not win him, however, to any conversation; he merely answered her
question and read on. At length, quite exhausted by the attempt to be
amused with her own book, which she had only chosen because it was the
second volume of his, she gave a great yawn and said, “How pleasant it
is to spend an evening in this way! I declare, after all, there is no
enjoyment like reading! How much sooner one tires of anything than of a
book! When I have a house of my own, I shall be miserable if I have not
an excellent library.”

No one made any reply. She then yawned again, threw aside her book, and
cast her eyes round the room in quest of some amusement; when, hearing
her brother mentioning a ball to Miss Bennet, she turned suddenly
towards him and said,--

“By the bye Charles, are you really serious in meditating a dance at
Netherfield? I would advise you, before you determine on it, to consult
the wishes of the present party; I am much mistaken if there are not
some among us to whom a ball would be rather a punishment than a
pleasure.”

“If you mean Darcy,” cried her brother, “he may go to bed, if he
chooses, before it begins; but as for the ball, it is quite a settled
thing, and as soon as Nicholls has made white soup enough I shall send
round my cards.”

“I should like balls infinitely better,” she replied, “if they were
carried on in a different manner; but there is something insufferably
tedious in the usual process of such a meeting. It would surely be much
more rational if conversation instead of dancing made the order of the
day.”

“Much more rational, my dear Caroline, I dare say; but it would not be
near so much like a ball.”

Miss Bingley made no answer, and soon afterwards got up and walked about
the room. Her figure was elegant, and she walked well; but Darcy, at
whom it was all aimed, was still inflexibly studious. In the
desperation of her feelings, she resolved on one effort more; and,
turning to Elizabeth, said,--

“Miss Eliza Bennet, let me persuade you to follow my example, and take a
turn about the room. I assure you it is very refreshing after sitting so
long in one attitude.”

Elizabeth was surprised, but agreed to it immediately. Miss Bingley
succeeded no less in the real object of her civility: Mr. Darcy looked
up. He was as much awake to the novelty of attention in that quarter as
Elizabeth herself could be, and unconsciously closed his book. He was
directly invited to join their party, but he declined it, observing that
he could imagine but two motives for their choosing to walk up and down
the room together, with either of which motives his joining them would
interfere. What could he mean? She was dying to know what could be his
meaning--and asked Elizabeth whether she could at all understand him.

“Not at all,” was her answer; “but, depend upon it, he means to be
severe on us, and our surest way of disappointing him will be to ask
nothing about it.”

Miss Bingley, however, was incapable of disappointing Mr. Darcy in
anything, and persevered, therefore, in requiring an explanation of his
two motives.

“I have not the smallest objection to explaining them,” said he, as soon
as she allowed him to speak. “You either choose this method of passing
the evening because you are in each other’s confidence, and have secret
affairs to discuss, or because you are conscious that your figures
appear to the greatest advantage in walking: if the first, I should be
completely in your way; and if the second, I can admire you much better
as I sit by the fire.”

“Oh, shocking!” cried Miss Bingley. “I never heard anything so
abominable. How shall we punish him for such a speech?”

“Nothing so easy, if you have but the inclination,” said Elizabeth. “We
can all plague and punish one another. Tease him--laugh at him. Intimate
as you are, you must know how it is to be done.”

“But upon my honour I do _not_. I do assure you that my intimacy has not
yet taught me _that_. Tease calmness of temper and presence of mind! No,
no; I feel he may defy us there. And as to laughter, we will not expose
ourselves, if you please, by attempting to laugh without a subject. Mr.
Darcy may hug himself.”

“Mr. Darcy is not to be laughed at!” cried Elizabeth. “That is an
uncommon advantage, and uncommon I hope it will continue, for it would
be a great loss to _me_ to have many such acquaintance. I dearly love a
laugh.”

“Miss Bingley,” said he, “has given me credit for more than can be. The
wisest and best of men,--nay, the wisest and best of their actions,--may
be rendered ridiculous by a person whose first object in life is a
joke.”

“Certainly,” replied Elizabeth, “there are such people, but I hope I am
not one of _them_. I hope I never ridicule what is wise or good. Follies
and nonsense, whims and inconsistencies, _do_ divert me, I own, and I
laugh at them whenever I can. But these, I suppose, are precisely what
you are without.”

“Perhaps that is not possible for anyone. But it has been the study of
my life to avoid those weaknesses which often expose a strong
understanding to ridicule.”

“Such as vanity and pride.”

“Yes, vanity is a weakness indeed. But pride--where there is a real
superiority of mind--pride will be always under good regulation.”

Elizabeth turned away to hide a smile.

“Your examination of Mr. Darcy is over, I presume,” said Miss Bingley;
“and pray what is the result?”

“I am perfectly convinced by it that Mr. Darcy has no defect. He owns it
himself without disguise.”

“No,” said Darcy, “I have made no such pretension. I have faults enough,
but they are not, I hope, of understanding. My temper I dare not vouch
for. It is, I believe, too little yielding; certainly too little for the
convenience of the world. I cannot forget the follies and vices of
others so soon as I ought, nor their offences against myself. My
feelings are not puffed about with every attempt to move them. My temper
would perhaps be called resentful. My good opinion once lost is lost for
ever.”

“_That_ is a failing, indeed!” cried Elizabeth. “Implacable resentment
_is_ a shade in a character. But you have chosen your fault well. I
really cannot _laugh_ at it. You are safe from me.”

“There is, I believe, in every disposition a tendency to some particular
evil, a natural defect, which not even the best education can overcome.”

“And _your_ defect is a propensity to hate everybody.”

“And yours,” he replied, with a smile, “is wilfully to misunderstand
them.”

“Do let us have a little music,” cried Miss Bingley, tired of a
conversation in which she had no share. “Louisa, you will not mind my
waking Mr. Hurst.”

Her sister made not the smallest objection, and the pianoforte was
opened; and Darcy, after a few moments’ recollection, was not sorry for
it. He began to feel the danger of paying Elizabeth too much attention.

[Illustration]

CHAPTER XII.

[Illustration]

In consequence of an agreement between the sisters, Elizabeth wrote the
next morning to her mother, to beg that the carriage might be sent for
them in the course of the day. But Mrs. Bennet, who had calculated on
her daughters remaining at Netherfield till the following Tuesday, which
would exactly finish Jane’s week, could not bring herself to receive
them with pleasure before. Her answer, therefore, was not propitious, at
least not to Elizabeth’s wishes, for she was impatient to get home. Mrs.
Bennet sent them word that they could not possibly have the carriage
before Tuesday; and in her postscript it was added, that if Mr. Bingley
and his sister pressed them to stay longer, she could spare them very
well. Against staying longer, however, Elizabeth was positively
resolved--nor did she much expect it would be asked; and fearful, on the
contrary, of being considered as intruding themselves needlessly long,
she urged Jane to borrow Mr. Bingley’s carriage immediately, and at
length it was settled that their original design of leaving Netherfield
that morning should be mentioned, and the request made.

The communication excited many professions of concern; and enough was
said of wishing them to stay at least till the following day to work on
Jane; and till the morrow their going was deferred. Miss Bingley was
then sorry that she had proposed the delay; for her jealousy and dislike
of one sister much exceeded her affection for the other.

The master of the house heard with real sorrow that they were to go so
soon, and repeatedly tried to persuade Miss Bennet that it would not be
safe for her--that she was not enough recovered; but Jane was firm where
she felt herself to be right.

To Mr. Darcy it was welcome intelligence: Elizabeth had been at
Netherfield long enough. She attracted him more than he liked; and Miss
Bingley was uncivil to _her_ and more teasing than usual to himself. He
wisely resolved to be particularly careful that no sign of admiration
should _now_ escape him--nothing that could elevate her with the hope of
influencing his felicity; sensible that, if such an idea had been
suggested, his behaviour during the last day must have material weight
in confirming or crushing it. Steady to his purpose, he scarcely spoke
ten words to her through the whole of Saturday: and though they were at
one time left by themselves for half an hour, he adhered most
conscientiously to his book, and would not even look at her.

On Sunday, after morning service, the separation, so agreeable to almost
all, took place. Miss Bingley’s civility to Elizabeth increased at last
very rapidly, as well as her affection for Jane; and when they parted,
after assuring the latter of the pleasure it would always give her to
see her either at Longbourn or Netherfield, and embracing her most
tenderly, she even shook hands with the former. Elizabeth took leave of
the whole party in the liveliest spirits.

They were not welcomed home very cordially by their mother. Mrs. Bennet
wondered at their coming, and thought them very wrong to give so much
trouble, and was sure Jane would have caught cold again. But their
father, though very laconic in his expressions of pleasure, was really
glad to see them; he had felt their importance in the family circle. The
evening conversation, when they were all assembled, had lost much of its
animation, and almost all its sense, by the absence of Jane and
Elizabeth.

They found Mary, as usual, deep in the study of thorough bass and human
nature; and had some new extracts to admire and some new observations of
threadbare morality to listen to. Catherine and Lydia had information
for them of a different sort. Much had been done, and much had been said
in the regiment since the preceding Wednesday; several of the officers
had dined lately with their uncle; a private had been flogged; and it
had actually been hinted that Colonel Forster was going to be married.

[Illustration]

CHAPTER XIII

[Illustration]

“I hope, my dear,” said Mr. Bennet to his wife, as they were at
breakfast the next morning, “that you have ordered a good dinner to-day,
because I have reason to expect an addition to our family party.”

“Who do you mean, my dear? I know of nobody that is coming, I am sure,
unless Charlotte Lucas should happen to call in; and I hope _my_ dinners
are good enough for her. I do not believe she often sees such at home.”

“The person of whom I speak is a gentleman and a stranger.”

Mrs. Bennet’s eyes sparkled. “A gentleman and a stranger! It is Mr.
Bingley, I am sure. Why, Jane--you never dropped a word of this--you sly
thing! Well, I am sure I shall be extremely glad to see Mr. Bingley.
But--good Lord! how unlucky! there is not a bit of fish to be got
to-day. Lydia, my love, ring the bell. I must speak to Hill this
moment.”

“It is _not_ Mr. Bingley,” said her husband; “it is a person whom I
never saw in the whole course of my life.”

This roused a general astonishment; and he had the pleasure of being
eagerly questioned by his wife and five daughters at once.

After amusing himself some time with their curiosity, he thus
explained:--“About a month ago I received this letter, and about a
fortnight ago I answered it; for I thought it a case of some delicacy,
and requiring early attention. It is from my cousin, Mr. Collins, who,
when I am dead, may turn you all out of this house as soon as he
pleases.”

“Oh, my dear,” cried his wife, “I cannot bear to hear that mentioned.
Pray do not talk of that odious man. I do think it is the hardest thing
in the world, that your estate should be entailed away from your own
children; and I am sure, if I had been you, I should have tried long ago
to do something or other about it.”

Jane and Elizabeth attempted to explain to her the nature of an entail.
They had often attempted it before: but it was a subject on which Mrs.
Bennet was beyond the reach of reason; and she continued to rail
bitterly against the cruelty of settling an estate away from a family of
five daughters, in favour of a man whom nobody cared anything about.

“It certainly is a most iniquitous affair,” said Mr. Bennet; “and
nothing can clear Mr. Collins from the guilt of inheriting Longbourn.
But if you will listen to his letter, you may, perhaps, be a little
softened by his manner of expressing himself.”

“No, that I am sure I shall not: and I think it was very impertinent of
him to write to you at all, and very hypocritical. I hate such false
friends. Why could not he keep on quarrelling with you, as his father
did before him?”

“Why, indeed, he does seem to have had some filial scruples on that
head, as you will hear.”

     /* RIGHT “Hunsford, near Westerham, Kent, _15th October_. */

“Dear Sir,

     “The disagreement subsisting between yourself and my late honoured
     father always gave me much uneasiness; and, since I have had the
     misfortune to lose him, I have frequently wished to heal the
     breach: but, for some time, I was kept back by my own doubts,
     fearing lest it might seem disrespectful to his memory for me to be
     on good terms with anyone with whom it had always pleased him to be
     at variance.”--‘There, Mrs. Bennet.’--“My mind, however, is now
     made up on the subject; for, having received ordination at Easter,
     I have been so fortunate as to be distinguished by the patronage of
     the Right Honourable Lady Catherine de Bourgh, widow of Sir Lewis
     de Bourgh, whose bounty and beneficence has preferred me to the
     valuable rectory of this parish, where it shall be my earnest
     endeavour to demean myself with grateful respect towards her
     Ladyship, and be ever ready to perform those rites and ceremonies
     which are instituted by the Church of England. As a clergyman,
     moreover, I feel it my duty to promote and establish the blessing
     of peace in all families within the reach of my influence; and on
     these grounds I flatter myself that my present overtures of
     good-will are highly commendable, and that the circumstance of my
     being next in the entail of Longbourn estate will be kindly
     overlooked on your side, and not lead you to reject the offered
     olive branch. I cannot be otherwise than concerned at being the
     means of injuring your amiable daughters, and beg leave to
     apologize for it, as well as to assure you of my readiness to make
     them every possible amends; but of this hereafter. If you should
     have no objection to receive me into your house, I propose myself
     the satisfaction of waiting on you and your family, Monday,
     November 18th, by four o’clock, and shall probably trespass on your
     hospitality till the Saturday se’nnight following, which I can do
     without any inconvenience, as Lady Catherine is far from objecting
     to my occasional absence on a Sunday, provided that some other
     clergyman is engaged to do the duty of the day. I remain, dear sir,
     with respectful compliments to your lady and daughters, your
     well-wisher and friend,

“WILLIAM COLLINS.”

“At four o’clock, therefore, we may expect this peace-making gentleman,”
said Mr. Bennet, as he folded up the letter. “He seems to be a most
conscientious and polite young man, upon my word; and, I doubt not, will
prove a valuable acquaintance, especially if Lady Catherine should be so
indulgent as to let him come to us again.”

“There is some sense in what he says about the girls, however; and, if
he is disposed to make them any amends, I shall not be the person to
discourage him.”

“Though it is difficult,” said Jane, “to guess in what way he can mean
to make us the atonement he thinks our due, the wish is certainly to his
credit.”

Elizabeth was chiefly struck with his extraordinary deference for Lady
Catherine, and his kind intention of christening, marrying, and burying
his parishioners whenever it were required.

“He must be an oddity, I think,” said she. “I cannot make him out. There
is something very pompous in his style. And what can he mean by
apologizing for being next in the entail? We cannot suppose he would
help it, if he could. Can he be a sensible man, sir?”

“No, my dear; I think not. I have great hopes of finding him quite the
reverse. There is a mixture of servility and self-importance in his
letter which promises well. I am impatient to see him.”

“In point of composition,” said Mary, “his letter does not seem
defective. The idea of the olive branch perhaps is not wholly new, yet I
think it is well expressed.”

To Catherine and Lydia neither the letter nor its writer were in any
degree interesting. It was next to impossible that their cousin should
come in a scarlet coat, and it was now some weeks since they had
received pleasure from the society of a man in any other colour. As for
their mother, Mr. Collins’s letter had done away much of her ill-will,
and she was preparing to see him with a degree of composure which
astonished her husband and daughters.

Mr. Collins was punctual to his time, and was received with great
politeness by the whole family. Mr. Bennet indeed said little; but the
ladies were ready enough to talk, and Mr. Collins seemed neither in need
of encouragement, nor inclined to be silent himself. He was a tall,
heavy-looking young man of five-and-twenty. His air was grave and
stately, and his manners were very formal. He had not been long seated
before he complimented Mrs. Bennet on having so fine a family of
daughters, said he had heard much of their beauty, but that, in this
instance, fame had fallen short of the truth; and added, that he did not
doubt her seeing them all in due time well disposed of in marriage. This
gallantry was not much to the taste of some of his hearers; but Mrs.
Bennet, who quarrelled with no compliments, answered most readily,--

“You are very kind, sir, I am sure; and I wish with all my heart it may
prove so; for else they will be destitute enough. Things are settled so
oddly.”

“You allude, perhaps, to the entail of this estate.”

“Ah, sir, I do indeed. It is a grievous affair to my poor girls, you
must confess. Not that I mean to find fault with _you_, for such things,
I know, are all chance in this world. There is no knowing how estates
will go when once they come to be entailed.”

“I am very sensible, madam, of the hardship to my fair cousins, and
could say much on the subject, but that I am cautious of appearing
forward and precipitate. But I can assure the young ladies that I come
prepared to admire them. At present I will not say more, but, perhaps,
when we are better acquainted----”

He was interrupted by a summons to dinner; and the girls smiled on each
other. They were not the only objects of Mr. Collins’s admiration. The
hall, the dining-room, and all its furniture, were examined and praised;
and his commendation of everything would have touched Mrs. Bennet’s
heart, but for the mortifying supposition of his viewing it all as his
own future property. The dinner, too, in its turn, was highly admired;
and he begged to know to which of his fair cousins the excellence of its
cookery was owing. But here he was set right by Mrs. Bennet, who assured
him, with some asperity, that they were very well able to keep a good
cook, and that her daughters had nothing to do in the kitchen. He begged
pardon for having displeased her. In a softened tone she declared
herself not at all offended; but he continued to apologize for about a
quarter of an hour.

[Illustration]

CHAPTER XIV

[Illustration]

During dinner, Mr. Bennet scarcely spoke at all; but when the servants
were withdrawn, he thought it time to have some conversation with his
guest, and therefore started a subject in which he expected him to
shine, by observing that he seemed very fortunate in his patroness. Lady
Catherine de Bourgh’s attention to his wishes, and consideration for his
comfort, appeared very remarkable. Mr. Bennet could not have chosen
better. Mr. Collins was eloquent in her praise. The subject elevated him
to more than usual solemnity of manner; and with a most important aspect
he protested that he had never in his life witnessed such behaviour in a
person of rank--such affability and condescension, as he had himself
experienced from Lady Catherine. She had been graciously pleased to
approve of both the discourses which he had already had the honour of
preaching before her. She had also asked him twice to dine at Rosings,
and had sent for him only the Saturday before, to make up her pool of
quadrille in the evening. Lady Catherine was reckoned proud by many
people, he knew, but _he_ had never seen anything but affability in her.
She had always spoken to him as she would to any other gentleman; she
made not the smallest objection to his joining in the society of the
neighbourhood, nor to his leaving his parish occasionally for a week or
two to visit his relations. She had even condescended to advise him to
marry as soon as he could, provided he chose with discretion; and had
once paid him a visit in his humble parsonage, where she had perfectly
approved all the alterations he had been making, and had even vouchsafed
to suggest some herself,--some shelves in the closets upstairs.

“That is all very proper and civil, I am sure,” said Mrs. Bennet, “and I
dare say she is a very agreeable woman. It is a pity that great ladies
in general are not more like her. Does she live near you, sir?”

“The garden in which stands my humble abode is separated only by a lane
from Rosings Park, her Ladyship’s residence.”

“I think you said she was a widow, sir? has she any family?”

“She has one only daughter, the heiress of Rosings, and of very
extensive property.”

“Ah,” cried Mrs. Bennet, shaking her head, “then she is better off than
many girls. And what sort of young lady is she? Is she handsome?”

“She is a most charming young lady, indeed. Lady Catherine herself says
that, in point of true beauty, Miss de Bourgh is far superior to the
handsomest of her sex; because there is that in her features which marks
the young woman of distinguished birth. She is unfortunately of a sickly
constitution, which has prevented her making that progress in many
accomplishments which she could not otherwise have failed of, as I am
informed by the lady who superintended her education, and who still
resides with them. But she is perfectly amiable, and often condescends
to drive by my humble abode in her little phaeton and ponies.”

“Has she been presented? I do not remember her name among the ladies at
court.”

“Her indifferent state of health unhappily prevents her being in town;
and by that means, as I told Lady Catherine myself one day, has deprived
the British Court of its brightest ornament. Her Ladyship seemed pleased
with the idea; and you may imagine that I am happy on every occasion to
offer those little delicate compliments which are always acceptable to
ladies. I have more than once observed to Lady Catherine, that her
charming daughter seemed born to be a duchess; and that the most
elevated rank, instead of giving her consequence, would be adorned by
her. These are the kind of little things which please her Ladyship, and
it is a sort of attention which I conceive myself peculiarly bound to
pay.”

“You judge very properly,” said Mr. Bennet; “and it is happy for you
that you possess the talent of flattering with delicacy. May I ask
whether these pleasing attentions proceed from the impulse of the
moment, or are the result of previous study?”

“They arise chiefly from what is passing at the time; and though I
sometimes amuse myself with suggesting and arranging such little elegant
compliments as may be adapted to ordinary occasions, I always wish to
give them as unstudied an air as possible.”

Mr. Bennet’s expectations were fully answered. His cousin was as absurd
as he had hoped; and he listened to him with the keenest enjoyment,
maintaining at the same time the most resolute composure of countenance,
and, except in an occasional glance at Elizabeth, requiring no partner
in his pleasure.

By tea-time, however, the dose had been enough, and Mr. Bennet was glad
to take his guest into the drawing-room again, and when tea was over,
glad to invite him

[Illustration:

“Protested
that he never read novels”      H.T Feb 94
]

to read aloud to the ladies. Mr. Collins readily assented, and a book
was produced; but on beholding it (for everything announced it to be
from a circulating library) he started back, and, begging pardon,
protested that he never read novels. Kitty stared at him, and Lydia
exclaimed. Other books were produced, and after some deliberation he
chose “Fordyce’s Sermons.” Lydia gaped as he opened the volume; and
before he had, with very monotonous solemnity, read three pages, she
interrupted him with,--

“Do you know, mamma, that my uncle Philips talks of turning away
Richard? and if he does, Colonel Forster will hire him. My aunt told me
so herself on Saturday. I shall walk to Meryton to-morrow to hear more
about it, and to ask when Mr. Denny comes back from town.”

Lydia was bid by her two eldest sisters to hold her tongue; but Mr.
Collins, much offended, laid aside his book, and said,--

“I have often observed how little young ladies are interested by books
of a serious stamp, though written solely for their benefit. It amazes
me, I confess; for certainly there can be nothing so advantageous to
them as instruction. But I will no longer importune my young cousin.”

Then, turning to Mr. Bennet, he offered himself as his antagonist at
backgammon. Mr. Bennet accepted the challenge, observing that he acted
very wisely in leaving the girls to their own trifling amusements. Mrs.
Bennet and her daughters apologized most civilly for Lydia’s
interruption, and promised that it should not occur again, if he would
resume his book; but Mr. Collins, after assuring them that he bore his
young cousin no ill-will, and should never resent her behaviour as any
affront, seated himself at another table with Mr. Bennet, and prepared
for backgammon.

[Illustration]
