/* eslint-disable */
/**
 * GENERATED FILE — DO NOT EDIT.
 *
 * Single source of truth: collections/conditions.json
 * Regenerate after editing the JSON: `npm run gen:curated-data` (from admin/).
 * curated_data_sync.standalone.ts fails CI if this file drifts from the JSON.
 *
 * Curated "when to use what" condition spine (Phase 1). US-government / public-domain sourcing.
 */
import type { ConditionsFile } from '../../types/conditions.js'

export const CONDITIONS_FILE: ConditionsFile = {
  "version": "2026-06-07",
  "conditions": [
    {
      "slug": "pain",
      "label": "Pain",
      "category": "Pain, fever & inflammation",
      "searchTerms": [
        "pain",
        "aches",
        "minor aches",
        "pain relief",
        "analgesic"
      ]
    },
    {
      "slug": "headache",
      "label": "Headache",
      "category": "Pain, fever & inflammation",
      "searchTerms": [
        "headache",
        "migraine",
        "head pain",
        "tension headache"
      ]
    },
    {
      "slug": "muscle-joint-pain",
      "label": "Muscle & joint pain",
      "category": "Pain, fever & inflammation",
      "searchTerms": [
        "muscular aches",
        "muscle aches",
        "backache",
        "arthritis",
        "joint pain",
        "minor pain of arthritis"
      ]
    },
    {
      "slug": "fever",
      "label": "Fever",
      "category": "Pain, fever & inflammation",
      "searchTerms": [
        "fever",
        "reduces fever",
        "fever reducer",
        "temporarily reduces fever"
      ]
    },
    {
      "slug": "menstrual-cramps",
      "label": "Menstrual cramps",
      "category": "Pain, fever & inflammation",
      "searchTerms": [
        "menstrual cramps",
        "menstrual pain",
        "period pain",
        "premenstrual"
      ]
    },
    {
      "slug": "cough",
      "label": "Cough",
      "category": "Cold, cough & allergy",
      "searchTerms": [
        "cough",
        "cough suppressant",
        "coughing",
        "controls cough"
      ]
    },
    {
      "slug": "nasal-congestion",
      "label": "Nasal congestion",
      "category": "Cold, cough & allergy",
      "searchTerms": [
        "nasal congestion",
        "stuffy nose",
        "sinus congestion",
        "decongestant",
        "nasal decongestant"
      ]
    },
    {
      "slug": "sore-throat",
      "label": "Sore throat",
      "category": "Cold, cough & allergy",
      "searchTerms": [
        "sore throat",
        "sore mouth",
        "minor sore throat",
        "throat pain"
      ]
    },
    {
      "slug": "common-cold",
      "label": "Common cold",
      "category": "Cold, cough & allergy",
      "searchTerms": [
        "common cold",
        "cold symptoms",
        "cold",
        "flu symptoms"
      ]
    },
    {
      "slug": "allergic-reaction",
      "label": "Allergies & allergic reactions",
      "category": "Cold, cough & allergy",
      "searchTerms": [
        "allergy",
        "allergic reactions",
        "hay fever",
        "antihistamine",
        "runny nose",
        "sneezing",
        "itchy watery eyes"
      ]
    },
    {
      "slug": "heartburn",
      "label": "Heartburn",
      "category": "Stomach & digestion",
      "searchTerms": [
        "heartburn",
        "acid indigestion",
        "acid reducer",
        "antacid",
        "sour stomach"
      ]
    },
    {
      "slug": "indigestion",
      "label": "Indigestion & upset stomach",
      "category": "Stomach & digestion",
      "searchTerms": [
        "indigestion",
        "upset stomach",
        "gas",
        "bloating",
        "fullness",
        "antacid"
      ]
    },
    {
      "slug": "nausea-vomiting",
      "label": "Nausea & vomiting",
      "category": "Stomach & digestion",
      "searchTerms": [
        "nausea",
        "vomiting",
        "upset stomach associated with nausea"
      ]
    },
    {
      "slug": "diarrhea",
      "label": "Diarrhea",
      "category": "Stomach & digestion",
      "searchTerms": [
        "diarrhea",
        "antidiarrheal",
        "loose stools",
        "traveler’s diarrhea"
      ]
    },
    {
      "slug": "constipation",
      "label": "Constipation",
      "category": "Stomach & digestion",
      "searchTerms": [
        "constipation",
        "laxative",
        "irregularity",
        "occasional constipation",
        "stool softener"
      ]
    },
    {
      "slug": "motion-sickness",
      "label": "Motion sickness",
      "category": "Stomach & digestion",
      "searchTerms": [
        "motion sickness",
        "travel sickness",
        "seasickness",
        "car sickness"
      ]
    },
    {
      "slug": "gas",
      "label": "Gas & bloating",
      "category": "Stomach & digestion",
      "searchTerms": [
        "gas",
        "bloating",
        "flatulence",
        "antigas",
        "pressure"
      ]
    },
    {
      "slug": "wounds-cuts",
      "label": "Wounds & cuts",
      "category": "Skin & wounds",
      "searchTerms": [
        "minor cuts",
        "scrapes",
        "wounds",
        "first aid antiseptic",
        "first aid to help prevent infection",
        "abrasions"
      ]
    },
    {
      "slug": "burns",
      "label": "Burns",
      "category": "Skin & wounds",
      "searchTerms": [
        "burns",
        "minor burns",
        "sunburn",
        "scald",
        "minor burn"
      ]
    },
    {
      "slug": "insect-bites-stings",
      "label": "Insect bites & stings",
      "category": "Skin & wounds",
      "searchTerms": [
        "insect bites",
        "insect stings",
        "bug bites",
        "bee sting",
        "itching from insect bites"
      ]
    },
    {
      "slug": "skin-rash-itch",
      "label": "Rash & itching",
      "category": "Skin & wounds",
      "searchTerms": [
        "itching",
        "rash",
        "skin irritation",
        "itchy skin",
        "minor skin irritations",
        "eczema"
      ]
    },
    {
      "slug": "poison-ivy",
      "label": "Poison ivy & plant rashes",
      "category": "Skin & wounds",
      "searchTerms": [
        "poison ivy",
        "poison oak",
        "poison sumac",
        "rashes due to poison ivy"
      ]
    },
    {
      "slug": "fungal-infection",
      "label": "Athlete’s foot & ringworm",
      "category": "Skin & wounds",
      "searchTerms": [
        "athlete’s foot",
        "ringworm",
        "jock itch",
        "antifungal",
        "fungal infection",
        "tinea"
      ]
    },
    {
      "slug": "dry-skin",
      "label": "Dry & chapped skin",
      "category": "Skin & wounds",
      "searchTerms": [
        "dry skin",
        "chapped skin",
        "chapped lips",
        "skin protectant",
        "cracked skin"
      ]
    },
    {
      "slug": "acne",
      "label": "Acne",
      "category": "Skin & wounds",
      "searchTerms": [
        "acne",
        "pimples",
        "blackheads",
        "acne treatment"
      ]
    },
    {
      "slug": "eye-irritation",
      "label": "Eye irritation & dryness",
      "category": "Eyes, ears & mouth",
      "searchTerms": [
        "eye irritation",
        "dry eyes",
        "red eyes",
        "eye redness",
        "itchy eyes",
        "lubricant eye"
      ]
    },
    {
      "slug": "earache",
      "label": "Earache & ear wax",
      "category": "Eyes, ears & mouth",
      "searchTerms": [
        "earache",
        "ear wax",
        "earwax removal",
        "ear pain",
        "swimmer’s ear"
      ]
    },
    {
      "slug": "canker-sores",
      "label": "Canker & cold sores",
      "category": "Eyes, ears & mouth",
      "searchTerms": [
        "canker sores",
        "cold sores",
        "mouth sores",
        "fever blisters",
        "oral pain"
      ]
    },
    {
      "slug": "toothache",
      "label": "Toothache",
      "category": "Eyes, ears & mouth",
      "searchTerms": [
        "toothache",
        "tooth pain",
        "dental pain",
        "oral analgesic"
      ]
    },
    {
      "slug": "sleeplessness",
      "label": "Sleeplessness",
      "category": "Sleep, stress & general",
      "searchTerms": [
        "sleeplessness",
        "insomnia",
        "sleep aid",
        "difficulty falling asleep",
        "nighttime"
      ]
    },
    {
      "slug": "dehydration",
      "label": "Dehydration",
      "category": "Sleep, stress & general",
      "searchTerms": [
        "dehydration",
        "oral rehydration",
        "electrolyte",
        "fluid loss",
        "replaces electrolytes"
      ]
    },
    {
      "slug": "hemorrhoids",
      "label": "Hemorrhoids",
      "category": "Sleep, stress & general",
      "searchTerms": [
        "hemorrhoids",
        "hemorrhoidal",
        "anal itching",
        "rectal"
      ]
    },
    {
      "slug": "yeast-infection",
      "label": "Vaginal yeast infection",
      "category": "Infections (OTC-treatable)",
      "searchTerms": [
        "vaginal yeast infection",
        "yeast infection",
        "vaginal antifungal",
        "candidiasis"
      ]
    },
    {
      "slug": "pinworm",
      "label": "Pinworm",
      "category": "Infections (OTC-treatable)",
      "searchTerms": [
        "pinworm",
        "pinworm infection",
        "pinworm treatment"
      ]
    },
    {
      "slug": "cold-sore-lip",
      "label": "Chapped & sun-protected lips",
      "category": "Sleep, stress & general",
      "searchTerms": [
        "lip protectant",
        "chapped lips",
        "sunburn protection lips",
        "lip balm"
      ]
    },
    {
      "slug": "eye-allergy",
      "label": "Eye allergies",
      "category": "Eyes, ears & mouth",
      "searchTerms": [
        "eye allergy",
        "itchy eyes due to allergies",
        "ocular itching",
        "allergic conjunctivitis"
      ]
    }
  ]
}
